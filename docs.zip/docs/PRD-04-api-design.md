# PRD-04: API DESIGN (Backend Endpoints)

## Base URL: `https://api.absensi.domain.com/api/v1`

## Authentication Header: `Authorization: Bearer {token}`

---

## 1. AUTH ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| POST | `/auth/login` | Login (email/NIM + password) | All |
| POST | `/auth/logout` | Logout (revoke token) | All |
| POST | `/auth/forgot-password` | Request reset password | All |
| POST | `/auth/reset-password` | Reset password dengan token | All |
| PUT | `/auth/change-password` | Ubah password | All |
| GET | `/auth/me` | Get current user profile | All |
| PUT | `/auth/update-profile` | Update profile | All |
| PUT | `/auth/update-fcm-token` | Update FCM token | All |

### Detail Request/Response:

#### POST `/auth/login`
```json
// Request
{
    "login": "mahasiswa@email.com atau 3202316055",
    "password": "password123"
}

// Response 200
{
    "success": true,
    "data": {
        "user": {
            "id": 1,
            "nama": "Muhammad Haris",
            "email": "haris@polnep.ac.id",
            "nim": "3202316055",
            "prodi": { "id": 2, "nama": "Teknik Informatika" },
            "roles": ["mahasiswa"],
            "enrollment_status": "approved",
            "must_change_password": false
        },
        "token": "1|abc123...",
        "token_type": "Bearer",
        "expires_at": "2026-06-27T00:00:00Z"
    }
}
```

---

## 2. ENROLLMENT ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| POST | `/enrollment/submit` | Submit embedding wajah | Mahasiswa |
| GET | `/enrollment/status` | Cek status enrollment | Mahasiswa |
| POST | `/enrollment/re-request` | Request re-enrollment | Mahasiswa |
| GET | `/enrollment/pending` | List enrollment pending | Admin Prodi |
| PUT | `/enrollment/{id}/approve` | Approve enrollment | Admin Prodi |
| PUT | `/enrollment/{id}/reject` | Reject enrollment | Admin Prodi |
| GET | `/enrollment/my-embedding` | Get embedding referensi (untuk cache lokal) | Mahasiswa |

### Detail:

#### POST `/enrollment/submit`
```json
// Request
{
    "embedding": [0.0234, -0.0891, 0.1456, ...],  // 192 float values
    "liveness_passed": true,
    "liveness_challenge": "smile",
    "device_model": "Samsung Galaxy A54",
    "device_os": "Android 14"
}

// Response 201
{
    "success": true,
    "message": "Enrollment berhasil disubmit. Menunggu approval admin.",
    "data": {
        "id": 1,
        "status": "pending",
        "submitted_at": "2026-05-27T08:00:00Z"
    }
}
```

---

## 3. ATTENDANCE ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| POST | `/attendance/check-in` | Check-in absensi | Mahasiswa |
| POST | `/attendance/check-out` | Check-out absensi | Mahasiswa |
| GET | `/attendance/today` | Jadwal & status absensi hari ini | Mahasiswa |
| GET | `/attendance/history` | Riwayat absensi | Mahasiswa |
| GET | `/attendance/summary` | Summary kehadiran (per semester) | Mahasiswa |
| POST | `/attendance/sync-offline` | Sync data absensi offline | Mahasiswa |
| GET | `/attendance/active-schedule` | Jadwal yang sedang berlangsung | Mahasiswa |

### Detail:

#### POST `/attendance/check-in`
```json
// Request
{
    "jadwal_id": 5,
    "latitude": -0.0263,
    "longitude": 109.3425,
    "gps_accuracy": 8.5,
    "face_distance": 0.7234,
    "face_threshold": 1.0,
    "liveness_passed": true,
    "liveness_challenge": "turn_left",
    "inference_time_ms": 145,
    "device_model": "Samsung Galaxy A54",
    "device_os": "Android 14",
    "app_version": "1.0.0",
    "mock_location_detected": false,
    "is_offline": false
}

// Response 200
{
    "success": true,
    "message": "Check-in berhasil",
    "data": {
        "attendance_id": 123,
        "status": "hadir",
        "checkin_time": "2026-05-27T07:05:00Z",
        "distance_to_geofence": 25.4,
        "alpha_menit": 0,
        "note": "Dalam toleransi waktu"
    }
}

// Response 200 (terlambat)
{
    "success": true,
    "message": "Check-in berhasil (terlambat)",
    "data": {
        "attendance_id": 124,
        "status": "hadir_terlambat",
        "checkin_time": "2026-05-27T07:45:00Z",
        "distance_to_geofence": 15.2,
        "alpha_menit": 45,
        "note": "Terlambat 45 menit dari jam mulai"
    }
}

// Response 200 (pending - terlambat melebihi batas)
{
    "success": true,
    "message": "Check-in tercatat. Menunggu approval dosen.",
    "data": {
        "attendance_id": 125,
        "status": "pending",
        "checkin_time": "2026-05-27T08:35:00Z",
        "distance_to_geofence": 10.1,
        "alpha_menit": 95,
        "note": "Melebihi batas terlambat. Menunggu keputusan dosen."
    }
}

// Response 422 (validasi gagal)
{
    "success": false,
    "message": "Validasi lokasi gagal",
    "error": {
        "code": "GEOFENCE_INVALID",
        "detail": "Anda berada 150m dari area perkuliahan (batas: 50m)"
    }
}

// Response 422 (mock location)
{
    "success": false,
    "message": "Terdeteksi manipulasi lokasi",
    "error": {
        "code": "MOCK_LOCATION_DETECTED",
        "detail": "Sistem mendeteksi penggunaan fake GPS"
    }
}
```

#### POST `/attendance/check-out`
```json
// Request (sama seperti check-in)
{
    "attendance_id": 123,
    "latitude": -0.0263,
    "longitude": 109.3425,
    "gps_accuracy": 8.5,
    "face_distance": 0.6891,
    "face_threshold": 1.0,
    "liveness_passed": true,
    "liveness_challenge": "blink",
    "inference_time_ms": 132,
    "device_model": "Samsung Galaxy A54",
    "device_os": "Android 14",
    "app_version": "1.0.0",
    "mock_location_detected": false,
    "is_offline": false
}

// Response 200
{
    "success": true,
    "message": "Check-out berhasil",
    "data": {
        "attendance_id": 123,
        "checkout_time": "2026-05-27T10:00:00Z",
        "durasi_efektif_menit": 175,
        "total_alpha_menit": 5,
        "status": "hadir"
    }
}
```

#### GET `/attendance/today`
```json
// Response 200
{
    "success": true,
    "data": [
        {
            "jadwal_id": 5,
            "mata_kuliah": "Matematika Diskrit",
            "dosen": "Yusril Eka Mahendra, M.TI",
            "hari": "Selasa",
            "jam_mulai": "07:00",
            "jam_selesai": "10:00",
            "ruangan": "Lab Komputer 1",
            "geofence": {
                "latitude": -0.0263,
                "longitude": 109.3425,
                "radius": 50
            },
            "attendance_status": "belum",
            "attendance_id": null
        },
        {
            "jadwal_id": 8,
            "mata_kuliah": "Statistika dan Probabilitas",
            "dosen": "Karfindo, S.Kom., M.Kom",
            "hari": "Selasa",
            "jam_mulai": "13:00",
            "jam_selesai": "15:00",
            "ruangan": "R. Teori 3",
            "geofence": {
                "latitude": -0.0265,
                "longitude": 109.3430,
                "radius": 50
            },
            "attendance_status": "belum",
            "attendance_id": null
        }
    ]
}
```

---

## 4. LEAVE REQUEST ENDPOINTS (Izin/Sakit)

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| POST | `/leaves` | Submit izin/sakit | Mahasiswa |
| GET | `/leaves/my` | List izin saya | Mahasiswa |
| GET | `/leaves/pending` | List izin pending (per dosen/admin) | Dosen, Admin |
| PUT | `/leaves/{id}/approve` | Approve izin | Dosen, Admin |
| PUT | `/leaves/{id}/reject` | Reject izin | Dosen, Admin |

---

## 5. ACADEMIC MANAGEMENT ENDPOINTS (Admin Prodi)

### Tahun Ajaran
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/academic/tahun-ajaran` | List tahun ajaran | Admin+ |
| POST | `/academic/tahun-ajaran` | Create tahun ajaran | Admin Prodi |
| PUT | `/academic/tahun-ajaran/{id}` | Update tahun ajaran | Admin Prodi |
| DELETE | `/academic/tahun-ajaran/{id}` | Delete tahun ajaran | Admin Prodi |
| PUT | `/academic/tahun-ajaran/{id}/activate` | Aktivasi | Admin Prodi |

### Semester
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/academic/semesters` | List semester | Admin+ |
| POST | `/academic/semesters` | Create semester | Admin Prodi |
| PUT | `/academic/semesters/{id}` | Update semester | Admin Prodi |
| DELETE | `/academic/semesters/{id}` | Delete semester | Admin Prodi |
| PUT | `/academic/semesters/{id}/activate` | Aktivasi | Admin Prodi |

### Mata Kuliah
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/academic/mata-kuliah` | List mata kuliah | Admin+ |
| POST | `/academic/mata-kuliah` | Create mata kuliah | Admin Prodi |
| PUT | `/academic/mata-kuliah/{id}` | Update mata kuliah | Admin Prodi |
| DELETE | `/academic/mata-kuliah/{id}` | Delete mata kuliah | Admin Prodi |
| POST | `/academic/mata-kuliah/{id}/assign-mahasiswa` | Assign mahasiswa | Admin Prodi |
| DELETE | `/academic/mata-kuliah/{id}/remove-mahasiswa` | Remove mahasiswa | Admin Prodi |
| GET | `/academic/mata-kuliah/{id}/mahasiswa` | List mahasiswa di MK | Admin+, Dosen |

### Jadwal
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/academic/jadwal` | List jadwal | Admin+ |
| POST | `/academic/jadwal` | Create jadwal | Admin Prodi |
| PUT | `/academic/jadwal/{id}` | Update jadwal | Admin Prodi |
| DELETE | `/academic/jadwal/{id}` | Delete jadwal | Admin Prodi |
| GET | `/academic/jadwal/today` | Jadwal hari ini | All |
| GET | `/academic/jadwal/dosen/{id}` | Jadwal per dosen | Dosen, Admin |

### Geofence
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/academic/geofences` | List geofence | Admin+ |
| POST | `/academic/geofences` | Create geofence | Admin Prodi |
| PUT | `/academic/geofences/{id}` | Update geofence | Admin Prodi |
| DELETE | `/academic/geofences/{id}` | Delete geofence | Admin Prodi |

---

## 6. USER MANAGEMENT ENDPOINTS

### Mahasiswa
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/users/mahasiswa` | List mahasiswa (filter prodi) | Admin+ |
| POST | `/users/mahasiswa` | Create mahasiswa | Admin Prodi |
| PUT | `/users/mahasiswa/{id}` | Update mahasiswa | Admin Prodi |
| DELETE | `/users/mahasiswa/{id}` | Delete (soft) mahasiswa | Admin Prodi |
| POST | `/users/mahasiswa/import` | Import bulk Excel | Admin Prodi |
| GET | `/users/mahasiswa/export` | Export Excel | Admin Prodi |
| GET | `/users/mahasiswa/{id}/detail` | Detail + rekap | Admin+, Dosen |

### Dosen
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/users/dosen` | List dosen | Admin+ |
| POST | `/users/dosen` | Create dosen | Admin Prodi/Jurusan |
| PUT | `/users/dosen/{id}` | Update dosen | Admin Prodi/Jurusan |
| DELETE | `/users/dosen/{id}` | Delete (soft) dosen | Admin Prodi/Jurusan |

### All Users (Super Admin)
| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/users` | List semua user | Super Admin |
| POST | `/users` | Create user (any role) | Super Admin |
| PUT | `/users/{id}` | Update user | Super Admin |
| DELETE | `/users/{id}` | Delete user | Super Admin |
| PUT | `/users/{id}/assign-role` | Assign role | Super Admin |
| PUT | `/users/{id}/toggle-status` | Aktif/nonaktif | Super Admin, Admin |

---

## 7. DOSEN ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/dosen/my-classes` | Kelas yang diampu | Dosen |
| GET | `/dosen/pending-approvals` | List pending approval | Dosen |
| PUT | `/dosen/attendance/{id}/approve` | Approve pending | Dosen |
| PUT | `/dosen/attendance/{id}/reject` | Reject pending | Dosen |
| POST | `/dosen/attendance/override` | Override manual | Dosen |
| GET | `/dosen/class/{jadwal_id}/today` | Kehadiran kelas hari ini | Dosen |
| GET | `/dosen/class/{mk_id}/recap` | Rekap per MK | Dosen |

---

## 8. SP (SURAT PERINGATAN) ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/sp/dashboard` | Overview SP per prodi | Admin+, Kaprodi |
| GET | `/sp/mahasiswa` | List mahasiswa + status SP | Admin+, Kaprodi |
| GET | `/sp/mahasiswa/{id}` | Detail SP mahasiswa | Admin+, Kaprodi |
| POST | `/sp/generate` | Generate dokumen SP | Admin Prodi |
| GET | `/sp/records` | List semua SP records | Admin+, Kaprodi, Kajur |
| GET | `/sp/records/{id}` | Detail SP record | Admin+, Kaprodi, Kajur |
| PUT | `/sp/records/{id}/sign-kaprodi` | TTD Kaprodi | Kaprodi |
| PUT | `/sp/records/{id}/sign-kajur` | TTD Ketua Jurusan | Kajur |
| GET | `/sp/records/{id}/document` | Download PDF SP | Admin+, Kaprodi, Kajur, Mahasiswa |
| GET | `/sp/my` | SP saya (mahasiswa) | Mahasiswa |

---

## 9. SETTINGS ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/settings/prodi/{id}` | Get setting prodi | Admin Prodi |
| PUT | `/settings/prodi/{id}` | Update setting prodi | Admin Prodi |
| GET | `/settings/system` | Get system settings | Super Admin |
| PUT | `/settings/system` | Update system settings | Super Admin |
| PUT | `/settings/test-mode` | Toggle test mode | Super Admin |

---

## 10. REKAP & REPORT ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/reports/attendance/by-mahasiswa/{id}` | Rekap per mahasiswa | Admin+, Dosen |
| GET | `/reports/attendance/by-matakuliah/{id}` | Rekap per MK | Admin+, Dosen |
| GET | `/reports/attendance/by-kelas` | Rekap per kelas | Admin+ |
| GET | `/reports/attendance/by-prodi/{id}` | Rekap per prodi | Admin+, Kaprodi |
| GET | `/reports/attendance/by-jurusan` | Rekap jurusan | Kajur, Admin Jur |
| GET | `/reports/export/excel` | Export Excel | Admin+ |
| GET | `/reports/export/pdf` | Export PDF | Admin+ |
| GET | `/reports/dashboard/admin-prodi` | Data dashboard admin | Admin Prodi |
| GET | `/reports/dashboard/kaprodi` | Data dashboard kaprodi | Kaprodi |
| GET | `/reports/dashboard/kajur` | Data dashboard kajur | Kajur |
| GET | `/reports/dashboard/dosen` | Data dashboard dosen | Dosen |

---

## 11. NOTIFICATION ENDPOINTS

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/notifications` | List notifikasi saya | All |
| GET | `/notifications/unread-count` | Jumlah belum dibaca | All |
| PUT | `/notifications/{id}/read` | Mark as read | All |
| PUT | `/notifications/read-all` | Mark all as read | All |

---

## 12. ANALISIS & EVALUASI ENDPOINTS (Super Admin)

| Method | Endpoint | Deskripsi | Role |
|--------|----------|-----------|------|
| GET | `/analysis/geofence` | Data evaluasi geofence | Super Admin |
| GET | `/analysis/face-verification` | Data evaluasi face verify | Super Admin |
| GET | `/analysis/latency` | Data evaluasi latensi | Super Admin |
| GET | `/analysis/attendance-sp` | Data evaluasi kehadiran & SP | Super Admin |
| GET | `/analysis/simultaneous-test` | Data uji simultan | Super Admin |
| GET | `/analysis/conventional-comparison` | Data perbandingan konvensional | Super Admin |
| GET | `/analysis/far-frr` | Hitung FAR & FRR | Super Admin |
| GET | `/analysis/documentation` | Dokumentasi teknis (rumus) | Super Admin |
| POST | `/analysis/conventional-data` | Input data konvensional (manual) | Super Admin |
