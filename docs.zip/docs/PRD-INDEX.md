# PRD INDEX
# Sistem Absensi Mahasiswa Berbasis Mobile
# Geolocation + Face Recognition (MobileFaceNet)
# Politeknik Negeri Pontianak - Jurusan Teknik Elektro

---

**Versi**: 1.0
**Tanggal**: 27 Mei 2026
**Author**: Yusril Eka Mahendra, M.TI
**Status**: Final Draft

---

## DAFTAR DOKUMEN PRD

| No | File | Isi | Halaman |
|----|------|-----|---------|
| 1 | [PRD-01-overview.md](./PRD-01-overview.md) | Overview, Tujuan, Scope, Hierarki Role (8 role), Tech Stack, Arsitektur Sistem | ~330 baris |
| 2 | [PRD-02-functional-requirements.md](./PRD-02-functional-requirements.md) | Functional Requirements: Auth, Enrollment, Absensi (Check-in/out), Izin/Sakit, Manajemen Akademik, Konfigurasi | ~350 baris |
| 3 | [PRD-02B-functional-requirements.md](./PRD-02B-functional-requirements.md) | Functional Requirements (lanjutan): Early Warning SP, Monitoring & Rekapitulasi, Dosen Approval, Notifikasi, Mode Pengujian | ~300 baris |
| 4 | [PRD-03-database-design.md](./PRD-03-database-design.md) | Database Design: ERD, 21 tabel MySQL lengkap dengan relasi, index, dan constraint | ~400 baris |
| 5 | [PRD-04-api-design.md](./PRD-04-api-design.md) | API Design: 80+ endpoint REST API, request/response format, error handling | ~350 baris |
| 6 | [PRD-05-flow-diagram.md](./PRD-05-flow-diagram.md) | Flow Diagram: 10 alur proses (Check-in, Check-out, Auto-close, Alpha, SP, Enrollment, Izin, Override, Offline Sync) | ~300 baris |
| 7 | [PRD-06-ui-ux-design.md](./PRD-06-ui-ux-design.md) | UI/UX Design: Design System, Mobile App (Mahasiswa + Dosen), Web Dashboard Layout, Sidebar per Role, Komponen UI | ~350 baris |
| 8 | [PRD-07-analisis-evaluasi.md](./PRD-07-analisis-evaluasi.md) | Menu Analisis & Evaluasi: 7 sub-menu (Geofence, Face Verify, Latensi, Kehadiran/SP, Uji Simultan, Perbandingan, Dokumentasi Teknis) | ~350 baris |
| 9 | [PRD-08-non-functional.md](./PRD-08-non-functional.md) | Non-Functional Requirements: Performance, Security, Anti-Spoofing, Deployment, Testing, Timeline, Risiko | ~300 baris |

---

## RINGKASAN SISTEM

### Platform
- **Mobile App** (Flutter): Untuk Mahasiswa dan Dosen
- **Web Dashboard** (Vue 3 + Vite + Tailwind): Untuk Super Admin, Ketua Jurusan, Admin Jurusan, Kaprodi, Admin Prodi, Dosen
- **Backend API** (Laravel 11): REST API penghubung semua platform
- **Database** (MySQL 8): Penyimpanan data

### Hierarki Role (7 Role)
1. Super Admin (Owner/Peneliti)
2. Ketua Jurusan
3. Admin Jurusan
4. Kaprodi
5. Admin Prodi
6. Dosen
7. Mahasiswa

### Fitur Utama
1. Absensi berbasis Face Verification (MobileFaceNet) + Geofencing
2. Active Liveness Detection (anti-spoofing)
3. Deteksi Mock Location (anti fake GPS)
4. Akumulasi alpha berbasis menit (presisi tinggi)
5. Early Warning System SP (SP1/SP2/SP3/DO) otomatis
6. Generate dokumen SP dengan tanda tangan digital (Kaprodi + Kajur)
7. Multi mata kuliah per hari (check-in/out per sesi)
8. Offline attendance mode (queue + sync)
9. Dashboard monitoring real-time per role
10. Menu Analisis & Evaluasi Sistem (khusus penelitian)
11. Mode Pengujian FAR/FRR
12. Export Excel/PDF
13. Push Notification (FCM)

### Aturan SP (Akumulasi Jam Alpha per Semester)
- AMAN: 0 - 15 jam
- SP1: 16 - 31 jam
- SP2: 32 - 37 jam
- SP3: 38 - 45 jam
- DO: >= 46 jam

### Flow Absensi
```
Geofence Valid → Liveness (1 challenge) → Face Match → Status Ditentukan → Simpan
```

### Timeline
- Total estimasi: ~22 minggu (5.5 bulan)
- Sesuai jadwal penelitian: Maret - November 2026
