# TASK MOBILE
# Sistem Absensi Mahasiswa - Flutter Mobile App Tasks (Low-Level Detail)

---

## ATURAN KERJA

> Setiap task dibuat sangat detail (low-level). Kerjakan secara berurutan.
> Setelah 1 task utama selesai → LAPOR → tunggu konfirmasi → lanjut task berikutnya.
> Task selesai ditandai ✅. Task in-progress ditandai 🔄.

---

## PHASE 8: MOBILE APP - FOUNDATION
**Estimasi: 2 minggu**

### Task 8.1: Inisialisasi Project Flutter
- [ ] Create Flutter project (`flutter create absensi_mobile`)
- [ ] Setup `pubspec.yaml` — tambah dependencies:
  - [ ] `dio` (HTTP client)
  - [ ] `flutter_riverpod` atau `flutter_bloc` (state management)
  - [ ] `go_router` (navigation/routing)
  - [ ] `shared_preferences` (local storage sederhana)
  - [ ] `hive` + `hive_flutter` (local database untuk offline queue)
  - [ ] `camera` (akses kamera)
  - [ ] `google_mlkit_face_detection` (ML Kit face detection)
  - [ ] `tflite_flutter` (MobileFaceNet inference)
  - [ ] `geolocator` (GPS location)
  - [ ] `safe_device` (mock location detection)
  - [ ] `google_maps_flutter` (peta)
  - [ ] `firebase_core` + `firebase_messaging` (FCM)
  - [ ] `image` (image processing)
  - [ ] `permission_handler` (request permissions)
  - [ ] `connectivity_plus` (cek koneksi internet)
  - [ ] `flutter_local_notifications` (local notification)
  - [ ] `path_provider` (file paths)
  - [ ] `cached_network_image` (cache images)
  - [ ] `flutter_svg` (SVG icons)
  - [ ] `intl` (date formatting)
- [ ] Setup folder structure:
  ```
  lib/
  ├── main.dart
  ├── app.dart
  ├── config/
  │   ├── app_config.dart        (API URL, constants)
  │   ├── app_theme.dart         (colors, typography, theme)
  │   └── app_routes.dart        (route definitions)
  ├── core/
  │   ├── network/
  │   │   ├── api_client.dart    (Dio setup + interceptors)
  │   │   ├── api_exceptions.dart
  │   │   └── connectivity_service.dart
  │   ├── storage/
  │   │   ├── local_storage.dart (SharedPreferences wrapper)
  │   │   └── hive_service.dart  (offline queue)
  │   └── utils/
  │       ├── date_utils.dart
  │       └── validators.dart
  ├── features/
  │   ├── auth/
  │   ├── home/
  │   ├── attendance/
  │   ├── history/
  │   ├── profile/
  │   └── dosen/               (fitur khusus dosen)
  ├── models/
  ├── services/
  │   ├── auth_service.dart
  │   ├── attendance_service.dart
  │   ├── face_recognition_service.dart
  │   ├── geolocation_service.dart
  │   ├── notification_service.dart
  │   └── offline_sync_service.dart
  └── widgets/
      ├── common/
      └── layout/
  ```
- [ ] Setup Android permissions di `AndroidManifest.xml`:
  - CAMERA
  - ACCESS_FINE_LOCATION
  - ACCESS_COARSE_LOCATION
  - INTERNET
  - ACCESS_NETWORK_STATE
- [ ] Setup minimum SDK version: Android 10 (API 29)
- [ ] Test: `flutter run` berjalan tanpa error

### Task 8.2: App Theme & Design System
- [ ] Buat `config/app_theme.dart`:
  - Color palette (sesuai PRD-06 design system)
  - Primary: #4F7CAC, Secondary: #6BBFAB
  - Status colors: success, warning, danger, info
  - Neutral colors: background, surface, border, text
- [ ] Typography setup (Inter font):
  - Heading styles (h1, h2, h3)
  - Body styles (body1, body2, caption)
  - Button text style
- [ ] ThemeData configuration:
  - AppBar theme
  - Card theme
  - Button themes (elevated, outlined, text)
  - Input decoration theme
  - Bottom navigation bar theme
- [ ] Test: theme applied correctly across app

### Task 8.3: API Client Setup (Dio)
- [ ] Buat `core/network/api_client.dart`:
  - Base URL configuration (from env/config)
  - Request interceptor: attach Bearer token from local storage
  - Response interceptor: handle 401 (auto logout + redirect login)
  - Error interceptor: parse error responses
  - Timeout configuration (30 seconds)
- [ ] Buat `core/network/api_exceptions.dart`:
  - Custom exception classes (NetworkException, AuthException, ValidationException)
  - Error message mapping
- [ ] Buat `core/network/connectivity_service.dart`:
  - Check internet connectivity
  - Listen to connectivity changes
  - Expose stream for UI to react
- [ ] Test: API call to backend → response parsed correctly

### Task 8.4: Authentication Flow
- [ ] Buat `models/user_model.dart` (from JSON, to JSON)
- [ ] Buat `services/auth_service.dart`:
  - `login(email, password)` → token + user
  - `logout()` → revoke token + clear local
  - `getMe()` → current user
  - `changePassword(old, new)` → success/error
  - `updateFcmToken(token)` → success
- [ ] Buat `features/auth/login_page.dart`:
  - Form: email/NIM + password
  - Login button
  - Forgot password link
  - Error display
  - Loading state
- [ ] Buat `features/auth/change_password_page.dart`:
  - Form: old + new + confirm
  - For first login (must_change_password)
- [ ] Buat auth state management:
  - AuthProvider/AuthBloc: user, token, isAuthenticated, isFirstLogin
  - Persist token to SharedPreferences
  - Auto-login on app start (if token exists)
- [ ] Buat route guard: redirect to login if not authenticated
- [ ] Buat role-based navigation: mahasiswa → mahasiswa UI, dosen → dosen UI
- [ ] Test: login → save token → restart app → still logged in

### Task 8.5: Navigation & Layout (Mahasiswa)
- [ ] Buat `app.dart` dengan GoRouter setup
- [ ] Buat bottom navigation bar (4 tabs):
  - Beranda (HomeIcon)
  - Absensi (LocationIcon)
  - Riwayat (ListIcon)
  - Profil (PersonIcon)
- [ ] Buat scaffold wrapper dengan bottom nav
- [ ] Active tab highlighting (primary color)
- [ ] Badge on Absensi tab (jika ada jadwal aktif)
- [ ] Test: navigate between tabs, state preserved

### Task 8.6: Navigation & Layout (Dosen)
- [ ] Buat bottom navigation bar dosen (4 tabs):
  - Beranda (HomeIcon)
  - Kelas (BookIcon)
  - Approval (CheckIcon) + badge count
  - Profil (PersonIcon)
- [ ] Buat scaffold wrapper dosen
- [ ] Test: dosen login → dosen UI shown

### Task 8.7: Home Screen (Mahasiswa)
- [ ] Buat `features/home/home_page.dart`:
  - Greeting card: "Selamat Pagi, [Nama]" + NIM + Prodi + Kelas
  - Status kehadiran semester card:
    - Persentase hadir
    - Count: hadir, alpha, izin, sakit
  - Akumulasi alpha card:
    - Progress bar (alpha / threshold SP berikutnya)
    - Status text (AMAN / SP1 / SP2 / SP3)
    - Sisa jam sebelum SP berikutnya
  - Jadwal hari ini list:
    - Per MK: jam, nama MK, ruangan, dosen, status absensi
    - Status: belum dimulai, sedang berlangsung, sudah selesai, sudah absen
  - Notifikasi terbaru (2-3 item)
- [ ] Buat API calls: `/attendance/today`, `/attendance/summary`, `/notifications`
- [ ] Pull-to-refresh
- [ ] Test: data dari API ditampilkan dengan benar

### Task 8.8: Home Screen (Dosen)
- [ ] Buat `features/dosen/dosen_home_page.dart`:
  - Greeting card: "Selamat Pagi, [Nama]" + NIDN
  - Quick stats cards:
    - Kelas hari ini: X
    - Pending approval: X
    - Kehadiran rata-rata: X%
  - Jadwal mengajar hari ini:
    - Per MK: jam, nama MK, ruangan, kelas
    - Status: belum mulai, sedang berlangsung, selesai
  - Notifikasi terbaru
- [ ] API calls: `/academic/jadwal/today`, `/dosen/pending-approvals`
- [ ] Test: data ditampilkan

### Task 8.9: Profile Screen (Mahasiswa)
- [ ] Buat `features/profile/profile_page.dart`:
  - User info card: foto, nama, NIM, prodi, kelas, angkatan
  - Menu list:
    - Enrollment Wajah (status + action)
    - Izin & Sakit (upload surat)
    - Status SP (detail)
    - Ubah Password
    - Pengaturan Notifikasi
    - Tentang Aplikasi
    - Logout
- [ ] Buat `features/profile/sp_status_page.dart`:
  - Progress bar akumulasi alpha
  - Riwayat SP (jika ada)
  - Download dokumen SP (jika ada)
- [ ] Buat logout confirmation dialog
- [ ] Test: semua menu navigasi berfungsi

### Task 8.10: Profile Screen (Dosen)
- [ ] Buat `features/dosen/dosen_profile_page.dart`:
  - User info card
  - Menu: Override Manual, Ubah Password, Logout
- [ ] Test: navigasi berfungsi

### Task 8.11: Firebase Cloud Messaging Setup
- [ ] Setup Firebase project (Android)
- [ ] Add `google-services.json` to android/app
- [ ] Initialize Firebase in `main.dart`
- [ ] Implement FCM token retrieval → send to backend
- [ ] Handle foreground notifications (show local notification)
- [ ] Handle background notifications
- [ ] Handle notification tap (navigate to relevant page)
- [ ] Test: send test notification from Firebase console → received

---

## PHASE 9: MOBILE APP - FACE RECOGNITION
**Estimasi: 3 minggu**

### Task 9.1: Camera Integration
- [ ] Buat `services/camera_service.dart`:
  - Initialize camera (front camera)
  - **Resolution: `ResolutionPreset.high` (1280x720)** — balance kualitas visual + performa ML
  - Start/stop camera preview
  - Capture frame dari stream (untuk ML processing real-time)
  - `takePicture()` untuk capture foto resolusi penuh (untuk enrollment biodata)
  - Get camera stream (for real-time detection)
  - Handle camera lifecycle (dispose, resume)
  - ImageFormatGroup: `yuv420` (untuk ML processing)
- [ ] Buat camera preview widget:
  - Full-screen camera view (720p — kualitas visual bagus)
  - Face frame overlay (oval guide)
  - Instruction text overlay
  - Challenge text overlay
  - Optional: ColorFilter ringan untuk brightness/contrast enhancement di preview
- [ ] Implement dual-mode capture:
  - **Stream mode** (real-time): frame 720p untuk ML Kit face detection + liveness
  - **Photo mode** (sekali): `controller.takePicture()` resolusi penuh HP untuk foto enrollment
  - Untuk MobileFaceNet: crop face dari frame 720p → resize 112x112 (resolusi asal tidak berpengaruh karena target hanya 112x112)
- [ ] Handle permissions (request camera permission)
- [ ] Test: camera preview shows (kualitas bagus, tidak buram), frames captured, takePicture works

### Task 9.2: ML Kit Face Detection
- [ ] Buat `services/face_detection_service.dart`:
  - Initialize ML Kit FaceDetector (with options):
    - Performance mode: accurate
    - Landmark mode: all
    - Classification mode: all (smile, eyes open)
    - Contour mode: none (not needed, save performance)
  - Process camera frame → detect faces
  - Return: face bounding box, landmarks, euler angles, probabilities
- [ ] Implement face validation checks:
  - `isSingleFace()`: exactly 1 face detected
  - `isFacingFront()`: euler angles within range (Y: -15 to 15, Z: -15 to 15)
  - `isNotWearingMask()`: mouth landmarks detected (nose tip, bottom lip visible)
  - `isEyesVisible()`: left/right eye open probability > 0.3
  - `isBrightnessOk()`: average luminance of face region > threshold
- [ ] Buat face detection overlay widget (bounding box drawn on preview)
- [ ] Test: detect face in real-time, validations work

### Task 9.3: Liveness Detection (Challenge-Response)
- [ ] Buat `services/liveness_service.dart`:
  - Define challenge types enum: SMILE, TURN_LEFT, TURN_RIGHT, BLINK, NOD
  - `getRandomChallenge()`: pick 1 random challenge
  - Per challenge, define detection logic:
    - SMILE: smilingProbability > 0.7
    - TURN_LEFT: headEulerAngleY < -20
    - TURN_RIGHT: headEulerAngleY > 20
    - BLINK: eyeOpenProbability < 0.3 then > 0.7 (detect transition)
    - NOD: headEulerAngleX change > 15 degrees (detect movement)
  - `startChallenge(type)`: start monitoring with timeout
  - `checkChallenge(faceData)`: check if challenge completed
  - Timeout: 10 seconds per challenge
- [ ] Buat liveness UI:
  - Challenge instruction text (large, clear)
  - Countdown timer (visual)
  - Success animation (green checkmark)
  - Failure message + retry button
- [ ] Buat challenge instruction strings (Bahasa Indonesia):
  - "Silakan SENYUM"
  - "Tolehkan kepala ke KIRI"
  - "Tolehkan kepala ke KANAN"
  - "KEDIPKAN mata Anda"
  - "ANGGUKKAN kepala Anda"
- [ ] Test: each challenge type detectable, timeout works

### Task 9.4: MobileFaceNet Integration (TFLite)
- [ ] Download/prepare MobileFaceNet model file (.tflite)
- [ ] Add model to `assets/models/mobilefacenet.tflite`
- [ ] Buat `services/face_recognition_service.dart`:
  - Load TFLite model on app start
  - `preprocessImage(face)`:
    - Crop face from frame (using bounding box)
    - Resize to 112x112
    - Convert to RGB (if YUV)
    - Normalize: (pixel - 127.5) / 127.5
    - Convert to Float32List input tensor [1, 112, 112, 3]
  - `getEmbedding(processedImage)`:
    - Run inference
    - Return Float32List [192]
    - Record inference time (t_start, t_end)
  - `compareEmbeddings(embedding1, embedding2)`:
    - Calculate Euclidean Distance
    - Return distance value (float)
  - `isMatch(distance, threshold)`:
    - Return true if distance < threshold
- [ ] Buat utility: YUV to RGB conversion (for camera frames)
- [ ] Test: model loads, inference runs, embedding generated (192 values)

### Task 9.5: Enrollment Flow (UI + Logic)
- [ ] Buat `features/attendance/enrollment_page.dart`:
  - Step 1: Instruction screen
    - "Pastikan pencahayaan cukup"
    - "Lepas masker dan kacamata hitam"
    - "Posisikan wajah di dalam frame"
    - Button: "Mulai Enrollment"
  - Step 2: Camera + face detection
    - Real-time face detection overlay
    - Validation indicators:
      - ✅/❌ 1 wajah terdeteksi
      - ✅/❌ Menghadap depan
      - ✅/❌ Tidak pakai masker
      - ✅/❌ Mata terdeteksi
      - ✅/❌ Pencahayaan cukup
    - All green → auto-proceed to liveness
  - Step 3: Liveness challenge
    - Show random challenge
    - Countdown timer
    - Success → proceed
    - Fail → retry
  - Step 4: Processing
    - **Foto enrollment**: gunakan `controller.takePicture()` → resolusi penuh HP (bukan dari stream)
      - Compress ke JPG quality 85% (~100-200KB)
      - Ini foto kualitas bagus untuk biodata/identitas visual
    - **Embedding**: ambil frame terakhir dari stream 720p
      - Crop face (bounding box dari ML Kit)
      - Resize ke 112x112
      - Normalize: (pixel - 127.5) / 127.5
      - Run MobileFaceNet → embedding [192 float]
      - (Resolusi asal tidak berpengaruh karena target hanya 112x112)
    - Show loading indicator
  - Step 5: Submit
    - Send embedding + foto enrollment ke backend (POST /enrollment/submit, multipart)
    - Backend simpan foto di storage, path disimpan di users.foto_enrollment
    - Show success: "Enrollment berhasil. Menunggu approval admin."
    - Navigate to home
- [ ] Handle errors: camera error, face not detected, liveness failed, network error
- [ ] Test: full enrollment flow end-to-end (embedding + foto tersimpan)

### Task 9.6: Face Verification Flow (Reusable - untuk Absensi)
- [ ] Buat `features/attendance/face_verification_widget.dart` (reusable widget):
  - Input: callback onVerificationComplete(success, distance, inferenceTime)
  - Camera preview with face overlay (720p — kualitas bagus)
  - Liveness challenge (1 random)
  - After liveness: ambil frame terakhir dari stream
  - Process: crop face → resize 112x112 → normalize → MobileFaceNet → embedding
  - Compare with stored reference embedding (from cache/API)
  - Return result: match/not match + distance + inference time
  - **PENTING: Tidak ada foto/embedding yang disimpan saat absensi**
  - Yang dikirim ke backend hanya: distance value, threshold, match result, inference time
  - Frame wajah dibuang dari memori setelah proses selesai
- [ ] Buat embedding cache:
  - Fetch reference embedding from API on login
  - Store in local storage (Hive)
  - Refresh on re-enrollment
- [ ] Test: verification works with cached embedding

---

## PHASE 10: MOBILE APP - ATTENDANCE FLOW
**Estimasi: 2 minggu**

### Task 10.1: Geolocation Service
- [ ] Buat `services/geolocation_service.dart`:
  - `getCurrentPosition()`: get lat, lon, accuracy
  - `checkMockLocation()`: using safe_device package
  - `calculateDistance(lat1, lon1, lat2, lon2)`: using Geolocator.distanceBetween
  - `isWithinGeofence(userLat, userLon, geofenceLat, geofenceLon, radius)`: boolean
  - Handle permission request (location permission)
  - Handle GPS disabled (prompt user to enable)
- [ ] Buat location status widget:
  - Show current GPS accuracy
  - Show distance to geofence
  - Show valid/invalid status
  - Show mock location warning (if detected)
- [ ] Test: get location, calculate distance, detect mock location

### Task 10.2: Attendance Screen (Check-in/Check-out)
- [ ] Buat `features/attendance/attendance_page.dart`:
  - Show active schedule (mata kuliah yang sedang berlangsung)
  - If no active schedule: "Tidak ada jadwal aktif saat ini"
  - If active schedule exists:
    - MK info card (nama, jam, ruangan, dosen)
    - Status validasi indicators:
      - 📍 Lokasi: checking... / ✅ Valid / ❌ Invalid
      - 🛡️ GPS: checking... / ✅ Asli / ❌ Fake detected
      - 😊 Liveness: waiting... / ✅ Passed
      - 🔐 Wajah: waiting... / ✅ Match / ❌ Not match
    - Button: CHECK-IN (if not checked in) / CHECK-OUT (if checked in)
    - Button disabled until all validations pass
- [ ] Implement check-in flow:
  1. User tap CHECK-IN
  2. Validate geofence (auto, show status)
  3. If geofence valid → open camera for liveness + face verify
  4. If face match → send to API
  5. Show result: success + status (hadir/terlambat/pending)
- [ ] Implement check-out flow (same steps)
- [ ] Show attendance result card after success:
  - Check-in time
  - Status
  - Alpha minutes (if any)
- [ ] Test: full check-in and check-out flow

### Task 10.3: Attendance Status Logic (Client-side)
- [ ] Implement time-based status determination (for UI feedback):
  - Fetch prodi settings (toleransi, batas terlambat)
  - Calculate: is within tolerance? is late? is over limit?
  - Show appropriate message before check-in:
    - "Anda tepat waktu ✅"
    - "Anda terlambat X menit (akan tercatat sebagai hadir terlambat)"
    - "Anda terlambat X menit (melebihi batas, perlu approval dosen)"
- [ ] Show countdown to class start (if before class)
- [ ] Show countdown to class end (if during class, for check-out)
- [ ] Test: status messages correct for various times

### Task 10.4: Offline Queue & Sync
- [ ] Buat `services/offline_sync_service.dart`:
  - Hive box for offline attendance queue
  - `queueAttendance(data)`: save to local when offline
  - `syncPendingAttendances()`: send all queued data to API when online
  - `getPendingCount()`: how many in queue
  - `clearSynced()`: remove synced items
- [ ] Implement connectivity listener:
  - When connection restored → auto-sync
  - Show sync status indicator in UI
- [ ] Implement offline attendance flow:
  - Geofence validation: use cached geofence coordinates
  - Liveness + face verify: all on-device (no network needed)
  - Save result locally with timestamp
  - Show: "Absensi tersimpan offline. Akan sync saat online."
- [ ] Handle sync failures:
  - If timestamp expired (>30 min after class) → show error
  - If success → update UI
- [ ] Show pending sync badge/indicator
- [ ] Test: go offline → absen → go online → auto sync

### Task 10.5: History Screen
- [ ] Buat `features/history/history_page.dart`:
  - Filter bar: semester dropdown, MK dropdown
  - Summary card:
    - Total hadir, alpha, izin, sakit
    - Akumulasi alpha (jam:menit)
    - Status SP
  - List view (grouped by date):
    - Per item: MK name, check-in time, check-out time, durasi, alpha, status
    - Status badge (color-coded)
    - Tap → detail view
  - Pagination (load more on scroll)
- [ ] Buat `features/history/history_detail_page.dart`:
  - Full detail of 1 attendance record
  - Check-in info: time, location, face distance
  - Check-out info: time, location, face distance
  - Duration, alpha minutes, status
- [ ] API calls: `/attendance/history`, `/attendance/summary`
- [ ] Test: history loads, filter works, pagination works

### Task 10.6: Leave Request (Izin/Sakit)
- [ ] Buat `features/profile/leave_request_page.dart`:
  - Form:
    - Jenis: dropdown (Izin / Sakit)
    - Mata Kuliah: dropdown (from enrolled MKs)
    - Tanggal mulai: date picker
    - Tanggal selesai: date picker
    - Keterangan: text area (optional)
    - Upload surat: file picker (camera / gallery / file)
  - Submit button
  - Validation: all required fields filled, file < 5MB
- [ ] Buat `features/profile/leave_history_page.dart`:
  - List izin/sakit yang pernah diajukan
  - Status: pending (kuning), approved (hijau), rejected (merah)
  - Tap → detail (lihat surat, alasan reject jika ada)
- [ ] API calls: POST `/leaves`, GET `/leaves/my`
- [ ] Test: submit izin + upload file → success

### Task 10.7: Dosen - Kelas & Approval
- [ ] Buat `features/dosen/dosen_class_page.dart`:
  - List kelas yang sedang berlangsung hari ini
  - Per kelas: tap → lihat siapa yang sudah check-in
  - Real-time list: mahasiswa + status (hadir/belum)
  - Counter: X/Y sudah hadir
  - Auto-refresh setiap 30 detik
- [ ] Buat `features/dosen/dosen_approval_page.dart`:
  - Tab: Pending Terlambat | Izin/Sakit
  - Per item: nama, NIM, MK, waktu, keterlambatan/jenis izin
  - Swipe or button: Approve / Reject
  - Confirm dialog before action
- [ ] Buat `features/dosen/dosen_override_page.dart`:
  - Form: pilih mahasiswa (search), pilih MK, pilih tanggal, status baru, alasan
  - Submit override
- [ ] API calls: dosen endpoints
- [ ] Test: approve/reject/override berfungsi

### Task 10.8: Push Notification Handling
- [ ] Handle notification types:
  - SP warning → navigate to SP status page
  - Approval result → navigate to history
  - Enrollment result → navigate to enrollment page
  - Reminder → navigate to attendance page
- [ ] Show in-app notification banner (foreground)
- [ ] Badge update on bottom nav (if relevant)
- [ ] Test: receive notification → tap → correct navigation

---

## PHASE 12: INTEGRATION & TESTING
**Estimasi: 3 minggu**

### Task 12.1: End-to-End Integration Testing
- [ ] Test full flow: Admin create MK + jadwal → Mahasiswa absen → Dosen approve → Rekap benar
- [ ] Test full flow: Mahasiswa terlambat → Pending → Dosen approve/reject → Alpha updated
- [ ] Test full flow: Mahasiswa alpha banyak → SP detected → Admin generate SP → Kaprodi sign → Kajur sign → PDF final
- [ ] Test full flow: Mahasiswa upload izin → Dosen approve → Alpha berkurang
- [ ] Test full flow: Enrollment → Admin approve → Bisa absen
- [ ] Test: multi MK per hari (check-in/out per sesi)
- [ ] Test: pinjam HP teman (login akun sendiri, face verify)
- [ ] Fix semua bug yang ditemukan

### Task 12.2: Load Testing (Uji Simultan)
- [ ] Setup load test tool (JMeter / k6)
- [ ] Skenario 1: 20 mahasiswa check-in bersamaan
- [ ] Skenario 2: 30 mahasiswa check-in bersamaan
- [ ] Skenario 3: 40 mahasiswa check-in bersamaan
- [ ] Record: response time, success rate, failure rate
- [ ] Identify bottlenecks → optimize
- [ ] Re-test after optimization
- [ ] Document results

### Task 12.3: Device Testing
- [ ] Test on low-end device (2GB RAM, Android 10):
  - Face detection speed
  - MobileFaceNet inference time
  - Overall app responsiveness
- [ ] Test on mid-range device (4GB RAM, Android 12):
  - Same metrics
- [ ] Test on high-end device (8GB+ RAM, Android 14):
  - Same metrics
- [ ] Record inference times per device
- [ ] Ensure app doesn't crash on low-end
- [ ] Document results (for Evaluasi Latensi)

### Task 12.4: Security Testing
- [ ] Test mock location detection (install fake GPS app → should be blocked)
- [ ] Test photo spoofing (show photo to camera → liveness should fail)
- [ ] Test video replay (play video → liveness should fail)
- [ ] Test wrong face (login as A, show face B → should fail)
- [ ] Test API without token → 401
- [ ] Test API with wrong role → 403
- [ ] Test SQL injection attempts → blocked
- [ ] Document results

### Task 12.5: FAR/FRR Testing (Mode Pengujian)
- [ ] Activate test mode
- [ ] Conduct genuine tests: 200 attempts (mahasiswa verify own face)
- [ ] Conduct impostor tests: 150 attempts (mahasiswa verify with wrong account)
- [ ] Record all distances + results
- [ ] Calculate FAR & FRR
- [ ] Determine optimal threshold
- [ ] Document results (for Evaluasi Face Verification)

### Task 12.6: Bug Fixing & Optimization
- [ ] Fix all critical bugs
- [ ] Fix all major bugs
- [ ] Optimize slow queries (add indexes if needed)
- [ ] Optimize API response times
- [ ] Optimize mobile app memory usage
- [ ] Optimize face detection/inference pipeline
- [ ] Final regression testing

---

## PHASE 13: FINAL POLISH & DEPLOYMENT
**Estimasi: 1 minggu**

### Task 13.1: VPS Setup & Deployment
- [ ] Setup VPS (Ubuntu 22.04)
- [ ] Install: Nginx, PHP 8.2, MySQL 8, Redis, Node.js, Composer, Supervisor
- [ ] Configure Nginx (reverse proxy for API + serve Vue build)
- [ ] Deploy Laravel backend
- [ ] Run migrations + seeders on production
- [ ] Deploy Vue frontend (npm run build → copy to nginx)
- [ ] Setup SSL (Certbot / Let's Encrypt)
- [ ] Configure Supervisor (queue worker)
- [ ] Setup Laravel scheduler (crontab)
- [ ] Configure firewall (UFW)
- [ ] Test: API accessible via HTTPS, dashboard accessible

### Task 13.2: Mobile App Build
- [ ] Update API base URL to production
- [ ] Build release APK (`flutter build apk --release`)
- [ ] Test APK on physical device
- [ ] Sign APK (keystore)
- [ ] Distribute APK (internal distribution / Play Store internal testing)

### Task 13.3: Final Verification
- [ ] Test semua fitur di production environment
- [ ] Test push notification di production
- [ ] Test export (Excel/PDF) di production
- [ ] Test offline sync di production
- [ ] Verify backup script works
- [ ] Verify monitoring alerts work
- [ ] Create admin accounts for real users
- [ ] Seed production data (prodi, tahun ajaran, semester)

### Task 13.4: Documentation
- [ ] Update PRD jika ada perubahan selama development
- [ ] API documentation (Swagger/Postman collection)
- [ ] User manual (brief): cara pakai untuk mahasiswa
- [ ] User manual (brief): cara pakai untuk admin/dosen
- [ ] Deployment documentation (how to redeploy)
