# TASK MASTER
# Sistem Absensi Mahasiswa - Master Timeline & Milestone

---

## ATURAN KERJA

> **PENTING: Baca ini sebelum mulai mengerjakan task apapun.**

### 1. Detail Level
Setiap task dibuat sangat detail (low-level). Setiap task utama memiliki sub-task yang spesifik, seperti: buat migration, buat model, buat controller, buat request validation, buat service layer, buat test, dll. Ini agar setiap detail pekerjaan terlihat jelas.

### 2. Alur Kerja
- Kerjakan task **secara berurutan** (sequential), tidak loncat-loncat
- Setiap task utama memiliki beberapa sub-task
- Kerjakan semua sub-task dalam 1 task utama sampai selesai
- **Setelah 1 task utama selesai → LAPOR dulu**
- Tanyakan: "Task X sudah selesai. Apakah kita lanjut ke task berikutnya?"
- **Tunggu konfirmasi** sebelum lanjut ke task berikutnya

### 3. Update Dokumentasi
- Setiap task yang sudah selesai **WAJIB** ditandai dengan ✅
- Format: `- [x] ✅ Nama task (SELESAI - tanggal)`
- Task yang sedang dikerjakan ditandai: `- [ ] 🔄 Nama task (IN PROGRESS)`
- Task yang belum dikerjakan: `- [ ] Nama task`

### 4. Checkpoint per Phase
- Di akhir setiap Phase, lakukan review bersama
- Pastikan semua task di phase tersebut sudah ✅
- Test/verifikasi hasil sebelum lanjut ke phase berikutnya
- Jika ada yang perlu diubah, perbaiki dulu sebelum lanjut

### 5. Git Strategy
```
main        ← production ready (deploy)
develop     ← development integration
feature/*   ← per fitur (branch dari develop)
```
- Setiap task utama = 1 feature branch
- Merge ke develop setelah task selesai
- Merge develop ke main di akhir setiap phase

### 6. Estimasi Waktu
- Setiap task memiliki estimasi waktu
- Estimasi bersifat panduan, bukan deadline kaku
- Jika ada blocker, komunikasikan segera

---

## TIMELINE OVERVIEW

| Phase | Nama | Durasi | Periode | Platform |
|-------|------|--------|---------|----------|
| 1 | Project Setup & Foundation | 1 minggu | Minggu 1 | Backend |
| 2 | Authentication & User Management | 1.5 minggu | Minggu 2-3 | Backend |
| 3 | Academic Module (CRUD) | 2 minggu | Minggu 3-5 | Backend |
| 4 | Attendance System (Core) | 2 minggu | Minggu 5-7 | Backend |
| 5 | SP & Early Warning System | 1.5 minggu | Minggu 7-8 | Backend |
| 6 | Notification & Export | 1 minggu | Minggu 9 | Backend |
| 7 | Web Dashboard (Vue) | 3 minggu | Minggu 10-12 | Frontend |
| 8 | Mobile App - Foundation | 2 minggu | Minggu 10-11 | Mobile |
| 9 | Mobile App - Face Recognition | 3 minggu | Minggu 12-14 | Mobile |
| 10 | Mobile App - Attendance Flow | 2 minggu | Minggu 15-16 | Mobile |
| 11 | Menu Analisis & Evaluasi | 2 minggu | Minggu 17-18 | Frontend |
| 12 | Integration & Testing | 3 minggu | Minggu 19-21 | All |
| 13 | Final Polish & Deployment | 1 minggu | Minggu 22 | All |

**Total: ~22 minggu**

---

## DEPENDENCY MAP

```
Phase 1 (Setup)
    │
    ▼
Phase 2 (Auth) ──────────────────────────────────────┐
    │                                                 │
    ▼                                                 │
Phase 3 (Academic CRUD)                               │
    │                                                 │
    ▼                                                 │
Phase 4 (Attendance API)──────────┐                   │
    │                             │                   │
    ▼                             │                   │
Phase 5 (SP System)               │                   │
    │                             │                   │
    ▼                             │                   │
Phase 6 (Notif & Export)          │                   │
    │                             │                   │
    ▼                             ▼                   ▼
Phase 7 (Web Dashboard) ◄── Butuh API Phase 2-6 ready
                                  │
Phase 8 (Mobile Foundation) ◄─────┤── Butuh Auth API ready
    │                             │
    ▼                             │
Phase 9 (Mobile Face Recog) ◄─────┤── Butuh Enrollment API ready
    │                             │
    ▼                             │
Phase 10 (Mobile Attendance) ◄────┘── Butuh Attendance API ready
    │
    ▼
Phase 11 (Analisis Menu) ◄── Butuh data dari Phase 4-5
    │
    ▼
Phase 12 (Integration & Test) ◄── Semua phase sebelumnya
    │
    ▼
Phase 13 (Deploy)
```

**Catatan Paralel:**
- Phase 7 (Web) dan Phase 8-10 (Mobile) bisa dikerjakan **paralel** setelah Phase 6 selesai
- Tapi karena kita berdua yang kerjakan, kita akan sequential: Backend dulu → lalu Web → lalu Mobile
- Atau: Backend → Web + Mobile bergantian per fitur

---

## MILESTONE CHECKLIST

### Phase 1: Project Setup & Foundation
- [ ] Laravel project initialized
- [ ] Database configured & connected
- [ ] All migrations created & run
- [ ] All models created with relationships
- [ ] Seeder untuk data awal (roles, prodis, settings)
- [ ] API response format standardized
- [ ] CORS configured
- [ ] Rate limiting configured

### Phase 2: Authentication & User Management
- [ ] Login/Logout API working
- [ ] Token management (Sanctum)
- [ ] Role-based middleware
- [ ] User CRUD (all roles)
- [ ] Password management (change, reset)
- [ ] FCM token update endpoint

### Phase 3: Academic Module
- [ ] Tahun Ajaran CRUD
- [ ] Semester CRUD
- [ ] Mata Kuliah CRUD + assign dosen/mahasiswa
- [ ] Jadwal CRUD + validasi bentrok
- [ ] Geofence CRUD
- [ ] Prodi Settings CRUD

### Phase 4: Attendance System
- [ ] Check-in endpoint (with all validations)
- [ ] Check-out endpoint
- [ ] Auto-close scheduler
- [ ] Alpha calculation service
- [ ] Offline sync endpoint
- [ ] Attendance logs recording
- [ ] Leave request (izin/sakit) CRUD + approval

### Phase 5: SP & Early Warning
- [ ] Alpha accumulation auto-calculate
- [ ] SP status detection
- [ ] SP document generation (PDF)
- [ ] SP approval flow (Kaprodi → Kajur)
- [ ] Digital signature integration

### Phase 6: Notification & Export
- [ ] FCM push notification service
- [ ] In-app notification CRUD
- [ ] Excel export (Maatwebsite)
- [ ] PDF export (DomPDF)
- [ ] Notification triggers configured

### Phase 7: Web Dashboard
- [ ] Vue project setup (Vite + Tailwind + Pinia)
- [ ] Layout (header, sidebar, footer)
- [ ] Auth pages (login, forgot password)
- [ ] Dashboard per role (4 dashboards)
- [ ] Academic CRUD pages
- [ ] User management pages
- [ ] Attendance monitoring pages
- [ ] SP management pages
- [ ] Settings pages
- [ ] Report & export pages

### Phase 8: Mobile Foundation
- [ ] Flutter project setup
- [ ] Auth flow (login, change password)
- [ ] Navigation (bottom nav)
- [ ] Home screen (jadwal hari ini)
- [ ] Profile screen
- [ ] API integration (Dio)
- [ ] Local storage setup

### Phase 9: Mobile Face Recognition
- [ ] Camera integration
- [ ] ML Kit face detection
- [ ] MobileFaceNet TFLite integration
- [ ] Liveness detection (challenge-response)
- [ ] Enrollment flow
- [ ] Face verification flow
- [ ] Anti-spoofing checks

### Phase 10: Mobile Attendance
- [ ] Geolocation integration
- [ ] Mock location detection
- [ ] Geofence validation
- [ ] Check-in flow (full)
- [ ] Check-out flow (full)
- [ ] Offline queue & sync
- [ ] History screen
- [ ] Leave request (upload surat)

### Phase 11: Menu Analisis & Evaluasi
- [ ] Evaluasi Geofence page
- [ ] Evaluasi Face Verification page
- [ ] Evaluasi Latensi page
- [ ] Evaluasi Kehadiran & SP page
- [ ] Uji Simultan page
- [ ] Perbandingan Konvensional page
- [ ] Dokumentasi Teknis page
- [ ] Mode Pengujian toggle

### Phase 12: Integration & Testing
- [ ] End-to-end testing (mobile → API → web)
- [ ] Load testing (40 concurrent users)
- [ ] Device testing (3 kategori HP)
- [ ] Bug fixing
- [ ] Performance optimization
- [ ] Security audit

### Phase 13: Final Polish & Deployment
- [ ] VPS setup & configuration
- [ ] Production deployment
- [ ] SSL certificate
- [ ] Final testing on production
- [ ] Documentation finalization
- [ ] APK build & distribution
