# TASK FRONTEND
# Sistem Absensi Mahasiswa - Vue.js Web Dashboard Tasks (Low-Level Detail)

---

## ATURAN KERJA

> Setiap task dibuat sangat detail (low-level). Kerjakan secara berurutan.
> Setelah 1 task utama selesai → LAPOR → tunggu konfirmasi → lanjut task berikutnya.
> Task selesai ditandai ✅. Task in-progress ditandai 🔄.

---

## PHASE 7: WEB DASHBOARD (Vue 3 + Vite + Tailwind)
**Estimasi: 3 minggu**

### Task 7.1: Inisialisasi Project Vue
- [ ] Create Vue 3 project via Vite (`npm create vite@latest`)
- [ ] Install dependencies:
  - [ ] `vue-router@4` (routing)
  - [ ] `pinia` (state management)
  - [ ] `axios` (HTTP client)
  - [ ] `tailwindcss` + `postcss` + `autoprefixer`
  - [ ] `@headlessui/vue` (UI components)
  - [ ] `@heroicons/vue` (icons)
  - [ ] `vue3-apexcharts` + `apexcharts` (charts)
  - [ ] `vee-validate` + `yup` (form validation)
  - [ ] `vue-toastification` (toast notifications)
  - [ ] `katex` (render rumus matematika)
  - [ ] `vue-pdf-embed` (PDF viewer)
  - [ ] `@vuepic/vue-datepicker` (date picker)
  - [ ] `xlsx` atau `file-saver` (download Excel)
- [ ] Configure Tailwind CSS (`tailwind.config.js` — custom colors sesuai design system)
- [ ] Setup folder structure:
  ```
  src/
  ├── assets/
  ├── components/
  │   ├── common/        (Button, Input, Modal, Table, Card, Badge, dll)
  │   ├── layout/        (Header, Sidebar, Footer, Breadcrumb)
  │   └── charts/        (LineChart, BarChart, PieChart, dll)
  ├── composables/       (useAuth, useNotification, useApi, dll)
  ├── layouts/
  │   ├── DashboardLayout.vue
  │   └── AuthLayout.vue
  ├── pages/
  │   ├── auth/
  │   ├── dashboard/
  │   ├── academic/
  │   ├── users/
  │   ├── attendance/
  │   ├── sp/
  │   ├── reports/
  │   ├── settings/
  │   └── analysis/
  ├── router/
  ├── stores/
  ├── services/          (API service classes)
  └── utils/
  ```
- [ ] Setup environment variables (`.env` — API base URL)
- [ ] Test: `npm run dev` berjalan tanpa error

### Task 7.2: Setup Routing & Guards
- [ ] Buat `router/index.js` dengan semua routes
- [ ] Route groups:
  - `/login` — public
  - `/forgot-password` — public
  - `/dashboard` — authenticated
  - `/academic/*` — admin_prodi, admin_jurusan, super_admin
  - `/users/*` — admin_prodi, admin_jurusan, super_admin
  - `/attendance/*` — admin_prodi, dosen, kaprodi
  - `/sp/*` — admin_prodi, kaprodi, kajur
  - `/reports/*` — all authenticated
  - `/settings/*` — admin_prodi, super_admin
  - `/analysis/*` — super_admin only
- [ ] Buat navigation guard: `beforeEach` — cek token, cek role
- [ ] Buat `meta` per route: `{ requiresAuth: true, roles: ['admin_prodi', 'super_admin'] }`
- [ ] Redirect unauthorized ke `/login` atau `/403`
- [ ] Test: akses route tanpa login → redirect ke login

### Task 7.3: Setup State Management (Pinia)
- [ ] Buat `stores/auth.js`:
  - State: user, token, isAuthenticated
  - Actions: login, logout, fetchUser, updateToken
  - Getters: userRole, userProdi, isRole(role)
- [ ] Buat `stores/notification.js`:
  - State: notifications, unreadCount
  - Actions: fetch, markRead, markAllRead
- [ ] Buat `stores/sidebar.js`:
  - State: isCollapsed, activeMenu
  - Actions: toggle, setActive
- [ ] Buat `stores/settings.js`:
  - State: prodiSettings, systemSettings
  - Actions: fetch, update
- [ ] Setup Pinia persistence (localStorage untuk token)
- [ ] Test: login → state tersimpan → refresh → masih login

### Task 7.4: Setup API Service Layer
- [ ] Buat `services/api.js` (Axios instance dengan interceptors):
  - Base URL dari env
  - Request interceptor: attach Bearer token
  - Response interceptor: handle 401 (auto logout), handle errors
- [ ] Buat `services/authService.js` (login, logout, me, changePassword)
- [ ] Buat `services/academicService.js` (tahunAjaran, semester, matkul, jadwal, geofence)
- [ ] Buat `services/userService.js` (mahasiswa, dosen, allUsers)
- [ ] Buat `services/attendanceService.js` (rekap, pending, enrollment)
- [ ] Buat `services/spService.js` (sp records, generate, sign)
- [ ] Buat `services/reportService.js` (reports, export)
- [ ] Buat `services/notificationService.js` (notifications)
- [ ] Buat `services/settingService.js` (prodi settings, system settings)
- [ ] Buat `services/analysisService.js` (semua endpoint analisis)
- [ ] Test: panggil API → response benar

### Task 7.5: Common Components
- [ ] Buat `components/common/AppButton.vue` (variants: primary, secondary, danger, ghost)
- [ ] Buat `components/common/AppInput.vue` (text, email, password, number, textarea)
- [ ] Buat `components/common/AppSelect.vue` (dropdown with search)
- [ ] Buat `components/common/AppModal.vue` (dialog with overlay)
- [ ] Buat `components/common/AppTable.vue` (sortable, pagination, search, filter)
- [ ] Buat `components/common/AppCard.vue` (stat card with icon, value, label, trend)
- [ ] Buat `components/common/AppBadge.vue` (status badges with colors)
- [ ] Buat `components/common/AppAlert.vue` (success, warning, error, info)
- [ ] Buat `components/common/AppPagination.vue`
- [ ] Buat `components/common/AppBreadcrumb.vue`
- [ ] Buat `components/common/AppLoading.vue` (spinner, skeleton)
- [ ] Buat `components/common/AppEmptyState.vue`
- [ ] Buat `components/common/AppConfirmDialog.vue`
- [ ] Buat `components/common/AppFileUpload.vue`
- [ ] Buat `components/common/AppDatePicker.vue`
- [ ] Buat `components/common/AppSearchFilter.vue` (search + filter bar)
- [ ] Semua component menggunakan Tailwind + design system colors
- [ ] Test: render semua component di storybook/test page

### Task 7.6: Layout Components
- [ ] Buat `components/layout/AppHeader.vue`:
  - Logo + app name (kiri)
  - Notification bell + badge count (kanan)
  - User dropdown: nama, role, profile, logout (kanan)
- [ ] Buat `components/layout/AppSidebar.vue`:
  - Collapsible sidebar
  - Menu items berdasarkan role (dynamic)
  - Active state highlight
  - Sub-menu (expandable)
  - Separator line (untuk menu Analisis)
- [ ] Buat `components/layout/AppFooter.vue`:
  - Copyright text
  - Version number
- [ ] Buat `layouts/DashboardLayout.vue`:
  - Header (fixed top)
  - Sidebar (fixed left, collapsible)
  - Main content area (scrollable)
  - Footer (bottom)
  - Responsive (sidebar overlay on mobile)
- [ ] Buat `layouts/AuthLayout.vue`:
  - Centered card layout
  - Background gradient/pattern
- [ ] Buat sidebar menu config per role (JSON/object)
- [ ] Test: layout responsive, sidebar collapse/expand

### Task 7.7: Chart Components
- [ ] Buat `components/charts/LineChart.vue` (wrapper ApexCharts)
- [ ] Buat `components/charts/BarChart.vue`
- [ ] Buat `components/charts/PieChart.vue`
- [ ] Buat `components/charts/StackedBarChart.vue`
- [ ] Buat `components/charts/BoxPlotChart.vue`
- [ ] Buat `components/charts/ScatterChart.vue`
- [ ] Buat `components/charts/ProgressBar.vue` (custom, untuk alpha accumulation)
- [ ] Buat `components/charts/HeatmapChart.vue`
- [ ] Semua chart: props-driven, responsive, theme colors sesuai design system
- [ ] Test: render chart dengan dummy data

### Task 7.8: Auth Pages
- [ ] Buat `pages/auth/LoginPage.vue`:
  - Form: email/NIM + password
  - Remember me checkbox
  - Forgot password link
  - Login button
  - Error handling (invalid credentials, locked account)
  - Redirect ke dashboard sesuai role setelah login
- [ ] Buat `pages/auth/ForgotPasswordPage.vue`:
  - Form: email
  - Send reset link button
  - Success message
- [ ] Buat `pages/auth/ResetPasswordPage.vue`:
  - Form: new password + confirm
  - Token dari URL params
- [ ] Buat `pages/auth/ChangePasswordPage.vue`:
  - Form: old password + new password + confirm
  - Untuk first login (must_change_password)
- [ ] Test: login flow end-to-end

### Task 7.9: Dashboard Pages (per Role)
- [ ] Buat `pages/dashboard/SuperAdminDashboard.vue`:
  - Cards: total user, total prodi, total mahasiswa, system status
  - Chart: kehadiran seluruh jurusan (line)
  - Table: recent activities / audit trail
- [ ] Buat `pages/dashboard/KajurDashboard.vue`:
  - Cards: total mahasiswa per prodi, total SP per prodi
  - Chart: perbandingan kehadiran antar prodi (grouped bar)
  - Chart: trend SP seluruh jurusan (line)
  - Table: pending SP documents (perlu TTD)
- [ ] Buat `pages/dashboard/AdminJurusanDashboard.vue`:
  - Cards: total mahasiswa, kehadiran hari ini
  - Chart: rekap lintas prodi
  - Table: summary per prodi
- [ ] Buat `pages/dashboard/KaprodiDashboard.vue`:
  - Cards: total mahasiswa prodi, SP1/SP2/SP3/DO count
  - Chart: trend SP per bulan (stacked bar)
  - Chart: persentase kehadiran per MK (horizontal bar)
  - Table: mahasiswa yang baru masuk SP (highlight)
  - Alert: pending SP documents
- [ ] Buat `pages/dashboard/AdminProdiDashboard.vue`:
  - Cards: total mahasiswa aktif, hadir hari ini, alpha hari ini, pending
  - Chart: trend kehadiran mingguan (line)
  - Chart: distribusi status (pie)
  - Chart: top 10 alpha terbanyak (bar)
  - Table: mahasiswa mendekati/sudah SP
  - Table: pending enrollment
- [ ] Buat `pages/dashboard/DosenDashboard.vue`:
  - Cards: kelas hari ini, pending approval, kehadiran rata-rata
  - Table: jadwal hari ini + status
  - Table: pending approval terbaru
- [ ] Dynamic dashboard: render berdasarkan role user yang login
- [ ] Test: setiap dashboard menampilkan data dari API

### Task 7.10: Academic CRUD Pages
- [ ] Buat `pages/academic/TahunAjaranPage.vue`:
  - Table: list tahun ajaran (kode, nama, tanggal, status)
  - Actions: create, edit, delete, activate
  - Modal: form create/edit
  - Confirm dialog: delete, activate
- [ ] Buat `pages/academic/SemesterPage.vue`:
  - Table: list semester (filter by tahun ajaran)
  - Actions: create, edit, delete, activate
  - Modal: form create/edit
  - Warning: aktivasi akan reset alpha
- [ ] Buat `pages/academic/MataKuliahPage.vue`:
  - Table: list MK (filter by semester, prodi)
  - Actions: create, edit, delete
  - Modal: form create/edit (pilih dosen, kelas)
  - Sub-page/modal: assign mahasiswa ke MK (multi-select)
- [ ] Buat `pages/academic/JadwalPage.vue`:
  - Table: list jadwal (filter by MK, hari, dosen)
  - Actions: create, edit, delete
  - Modal: form create/edit (pilih MK, geofence, hari, jam)
  - Validasi bentrok (tampilkan warning)
  - Calendar view (optional)
- [ ] Buat `pages/academic/GeofencePage.vue`:
  - Table: list geofence (nama, koordinat, radius, gedung)
  - Actions: create, edit, delete
  - Modal: form create/edit dengan map picker (Leaflet/Google Maps)
  - Preview radius di peta
- [ ] Test: semua CRUD berfungsi (create, read, update, delete)

### Task 7.11: User Management Pages
- [ ] Buat `pages/users/MahasiswaPage.vue`:
  - Table: list mahasiswa (filter prodi, kelas, angkatan, status, enrollment)
  - Actions: create, edit, delete, view detail
  - Modal: form create/edit
  - Button: import Excel (upload file)
  - Button: export Excel
  - Detail view: data + rekap kehadiran + status SP
- [ ] Buat `pages/users/DosenPage.vue`:
  - Table: list dosen (filter prodi)
  - Actions: create, edit, delete
  - Modal: form create/edit
- [ ] Buat `pages/users/AllUsersPage.vue` (Super Admin):
  - Table: semua user (filter role, prodi, status)
  - Actions: create, edit, delete, assign role, toggle status
  - Modal: form create/edit (pilih role)
- [ ] Test: semua CRUD + import/export

### Task 7.12: Attendance Management Pages
- [ ] Buat `pages/attendance/RekapPage.vue`:
  - Filter: semester, prodi, kelas, MK, mahasiswa
  - Table: rekap kehadiran (matrix view atau list view)
  - Detail per mahasiswa (modal/drawer)
  - Export button (Excel/PDF)
- [ ] Buat `pages/attendance/PendingApprovalPage.vue`:
  - Table: list pending (nama, MK, waktu checkin, keterlambatan)
  - Actions: approve, reject (dengan modal konfirmasi)
  - Bulk approve/reject
- [ ] Buat `pages/attendance/EnrollmentPage.vue`:
  - Table: list enrollment pending (nama, NIM, tanggal, status liveness)
  - Actions: approve, reject (dengan alasan)
  - Tab: pending, approved, rejected
- [ ] Buat `pages/attendance/ReEnrollmentPage.vue`:
  - Table: list re-enrollment requests
  - Actions: approve, reject
- [ ] Buat `pages/attendance/OverridePage.vue` (Dosen):
  - Form: pilih mahasiswa, MK, tanggal, status baru, alasan
  - Submit override
  - Riwayat override
- [ ] Buat `pages/attendance/LeaveRequestPage.vue`:
  - Table: list izin/sakit (filter status)
  - Actions: approve, reject
  - View uploaded file (modal/new tab)
- [ ] Test: semua halaman berfungsi

### Task 7.13: SP Management Pages
- [ ] Buat `pages/sp/MonitoringPage.vue`:
  - Cards: count per SP level
  - Table: mahasiswa + status SP (sortable, filterable)
  - Progress bar per mahasiswa (visual alpha vs threshold)
  - Filter: prodi, kelas, status SP
  - Action: generate SP (untuk admin)
- [ ] Buat `pages/sp/GeneratePage.vue`:
  - Pilih mahasiswa yang eligible untuk SP
  - Preview data (nama, NIM, total alpha, rincian per MK)
  - Button: Generate Draft
  - Button: Kirim ke Kaprodi
- [ ] Buat `pages/sp/DocumentsPage.vue`:
  - Table: list dokumen SP (filter: level, status, prodi)
  - Status flow visual (draft → kaprodi → kajur → final)
  - Actions: sign (kaprodi/kajur), download PDF, cancel
  - PDF preview (vue-pdf-embed)
- [ ] Buat `pages/sp/SignPage.vue` (Kaprodi/Kajur):
  - List dokumen yang menunggu tanda tangan
  - Preview PDF
  - Button: Tanda Tangani & Approve
  - Button: Tolak (dengan alasan)
- [ ] Test: full flow generate → sign → final → download

### Task 7.14: Report & Export Pages
- [ ] Buat `pages/reports/ReportPage.vue`:
  - Tab: Per Mahasiswa, Per MK, Per Kelas, Per Prodi
  - Filter per tab
  - Table + chart visualization
  - Export buttons (Excel, PDF)
- [ ] Buat `pages/reports/MahasiswaDetailReport.vue`:
  - Detail 1 mahasiswa: semua MK, semua pertemuan
  - Timeline kehadiran
  - Alpha accumulation progress
- [ ] Test: report data benar + export berfungsi

### Task 7.15: Settings Pages
- [ ] Buat `pages/settings/ProdiSettingPage.vue`:
  - Form: toleransi masuk, batas terlambat, toleransi pulang
  - Form: threshold SP (SP1, SP2, SP3, DO)
  - Form: face threshold, liveness settings
  - Form: geofence default radius, GPS accuracy
  - Form: notification settings
  - Save button per section
- [ ] Buat `pages/settings/SystemSettingPage.vue` (Super Admin):
  - App name, institution name
  - Test mode toggle
  - Global settings
- [ ] Buat `pages/settings/TestModePage.vue` (Super Admin):
  - Toggle test mode ON/OFF
  - Instruksi penggunaan mode pengujian
  - Status: aktif/nonaktif
- [ ] Test: update settings → verify di database

### Task 7.16: Notification UI
- [ ] Buat notification dropdown di Header:
  - Bell icon + unread count badge
  - Dropdown: list 5 notifikasi terbaru
  - Link: "Lihat semua"
- [ ] Buat `pages/notifications/NotificationPage.vue`:
  - List semua notifikasi (pagination)
  - Filter: type, read/unread
  - Mark as read (individual + all)
  - Click → navigate ke related page
- [ ] Real-time update (polling setiap 30 detik atau WebSocket)
- [ ] Test: notifikasi muncul, mark read berfungsi

---

## PHASE 11: MENU ANALISIS & EVALUASI SISTEM
**Estimasi: 2 minggu**

### Task 11.1: Evaluasi Geofence Page
- [ ] Buat `pages/analysis/GeofenceEvalPage.vue`
- [ ] Section: Penjelasan Rumus (KaTeX render Haversine formula)
  - Render rumus dengan KaTeX
  - Tabel penjelasan variabel (variabel, penjelasan, sumber data)
- [ ] Section: Data Tabel
  - Table: semua record validasi geofence (dari attendance_logs)
  - Kolom: tanggal, mahasiswa, MK, koordinat, jarak, radius, status, mock location
  - Filter: rentang tanggal, prodi, lokasi, status
  - Pagination
- [ ] Section: Chart & Statistik
  - Pie chart: valid vs invalid
  - Histogram: distribusi jarak
  - Line chart: akurasi GPS rata-rata per hari
  - Stat cards: total percobaan, success rate, rata-rata jarak, mock detected
- [ ] Test: data dari API ditampilkan dengan benar

### Task 11.2: Evaluasi Face Verification Page
- [ ] Buat `pages/analysis/FaceVerifyEvalPage.vue`
- [ ] Section: Penjelasan Rumus (KaTeX)
  - Euclidean Distance formula + penjelasan variabel
  - FAR formula + penjelasan variabel + interpretasi
  - FRR formula + penjelasan variabel + interpretasi
- [ ] Section: Data Tabel (Semua Percobaan)
  - Table: semua percobaan face verification
  - Kolom: tanggal, mahasiswa (akun), jenis (genuine/impostor), distance, threshold, hasil, benar/salah
  - Filter: jenis percobaan, rentang tanggal
- [ ] Section: Hasil FAR & FRR
  - Card: threshold yang digunakan
  - Card genuine: N_genuine, True Accept, N_FR, FRR (%)
  - Card impostor: N_impostor, True Reject, N_FA, FAR (%)
  - Card: Overall Accuracy
- [ ] Section: Chart
  - Scatter plot: distribusi distance (genuine vs impostor, warna beda)
  - Histogram overlay: genuine (biru) vs impostor (merah)
  - Line chart: FAR & FRR vs threshold (untuk cari optimal)
- [ ] Test: kalkulasi FAR/FRR benar

### Task 11.3: Evaluasi Latensi Page
- [ ] Buat `pages/analysis/LatencyEvalPage.vue`
- [ ] Section: Penjelasan Rumus (KaTeX)
  - t_infer formula + penjelasan
  - rata-rata_latensi formula + penjelasan
  - Statistik tambahan (min, max, P95, std dev)
- [ ] Section: Data Tabel
  - Table: semua record inference time
  - Kolom: tanggal, mahasiswa, device model, OS, inference time (ms), kategori device
  - Filter: device model, kategori, rentang tanggal
- [ ] Section: Summary per Device
  - Table: device model, kategori, jumlah test, min, max, rata-rata, P95, std dev
- [ ] Section: Chart
  - Box plot: distribusi latensi per device
  - Bar chart: rata-rata latensi per device
  - Line chart: trend latensi over time
  - Histogram: distribusi waktu inferensi keseluruhan
- [ ] Test: statistik dihitung dengan benar

### Task 11.4: Evaluasi Kehadiran & SP Page
- [ ] Buat `pages/analysis/AttendanceSpEvalPage.vue`
- [ ] Section: Penjelasan Rumus (KaTeX)
  - Persentase kehadiran formula + penjelasan
  - Akumulasi alpha formula + penjelasan
  - Tabel threshold SP
- [ ] Section: Chart & Statistik
  - Stacked bar: distribusi status SP per prodi
  - Line chart: trend akumulasi alpha rata-rata per minggu
  - Pie chart: distribusi status (Aman/SP1/SP2/SP3/DO)
  - Heatmap: kehadiran per mahasiswa per minggu
  - Stat cards: count per status SP, rata-rata persentase kehadiran
- [ ] Section: Detail per Mahasiswa
  - Table: mahasiswa + total alpha + status SP + progress bar
  - Filter: prodi, kelas, status
- [ ] Test: data dan chart sesuai

### Task 11.5: Uji Simultan Page
- [ ] Buat `pages/analysis/SimultaneousTestPage.vue`
- [ ] Section: Penjelasan Parameter
  - Skenario pengujian (20, 30, 40 mahasiswa)
  - Parameter yang diukur (response time, success rate, dll)
- [ ] Section: Tabel Hasil
  - Table: skenario, concurrent users, avg response time, max response time, success/failure/timeout rate
- [ ] Section: Chart
  - Line chart: response time vs concurrent users
  - Bar chart: success/failure/timeout rate per skenario
  - Box plot: distribusi response time per skenario
- [ ] Test: data ditampilkan dengan benar

### Task 11.6: Perbandingan Konvensional vs Sistem Page
- [ ] Buat `pages/analysis/ConventionalComparisonPage.vue`
- [ ] Section: Penjelasan Parameter
  - Apa yang dibandingkan (waktu, akurasi, error, real-time)
- [ ] Section: Form Input Data Konvensional
  - Form: tanggal, MK, jumlah mahasiswa, waktu proses, kesalahan, waktu rekap, catatan
  - Submit → simpan ke backend
  - Table: riwayat data konvensional yang sudah diinput
- [ ] Section: Tabel Perbandingan
  - Table: parameter, konvensional (dari input), sistem digital (dari data aktual), peningkatan
  - Auto-calculate peningkatan (%)
- [ ] Test: input data + perbandingan benar

### Task 11.7: Dokumentasi Teknis Page
- [ ] Buat `pages/analysis/TechnicalDocPage.vue`
- [ ] Accordion/Tab layout:
  - Tab 1: Pra-Pemrosesan Citra (YUV→RGB) — rumus + penjelasan
  - Tab 2: Normalisasi Input — rumus + penjelasan
  - Tab 3: MobileFaceNet Architecture — diagram + penjelasan
  - Tab 4: Euclidean Distance & Threshold — rumus + penjelasan
  - Tab 5: Geofencing (Haversine) — rumus + penjelasan
  - Tab 6: Perhitungan SP — aturan + penjelasan
  - Tab 7: Metrik Evaluasi (FAR, FRR, Latensi) — rumus + penjelasan
- [ ] Semua rumus di-render dengan KaTeX
- [ ] Penjelasan variabel dalam tabel yang rapi
- [ ] Test: semua tab render dengan benar, rumus terbaca
