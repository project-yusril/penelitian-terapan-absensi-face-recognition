# TASK BACKEND
# Sistem Absensi Mahasiswa - Laravel API Tasks (Low-Level Detail)

---

## ATURAN KERJA

> Setiap task dibuat sangat detail (low-level). Kerjakan secara berurutan.
> Setelah 1 task utama selesai → LAPOR → tunggu konfirmasi → lanjut task berikutnya.
> Task selesai ditandai ✅. Task in-progress ditandai 🔄.

---

## PHASE 1: PROJECT SETUP & FOUNDATION
**Estimasi: 1 minggu**

### Task 1.1: Inisialisasi Project Laravel
- [ ] Install Laravel 11 via composer (`composer create-project laravel/laravel`)
- [ ] Setup `.env` (DB_DATABASE=absensi_mahasiswa_elektro, app name, app URL)
- [ ] Install package dependencies:
  - [ ] `laravel/sanctum` (authentication)
  - [ ] `spatie/laravel-permission` (role & permission) atau manual role
  - [ ] `maatwebsite/excel` (export Excel)
  - [ ] `barryvdh/laravel-dompdf` (export PDF)
  - [ ] `kreait/laravel-firebase` (FCM push notification)
  - [ ] `l5-swagger` (API documentation) — optional
- [ ] Configure `config/cors.php` (allow mobile & web origins)
- [ ] Configure `config/sanctum.php` (token expiration)
- [ ] Setup rate limiting di `app/Providers/RouteServiceProvider.php`
- [ ] Buat base API response helper (`app/Helpers/ApiResponse.php`)
- [ ] Buat base controller (`app/Http/Controllers/Api/BaseController.php`)
- [ ] Setup exception handler untuk API responses
- [ ] Test: `php artisan serve` berjalan tanpa error

### Task 1.2: Database Migrations
- [ ] Migration: `create_roles_table`
- [ ] Migration: `create_prodis_table`
- [ ] Migration: `create_users_table` (dengan semua kolom sesuai PRD-03)
- [ ] Migration: `create_user_roles_table` (pivot)
- [ ] Migration: `create_face_embeddings_table`
- [ ] Migration: `create_re_enrollment_requests_table`
- [ ] Migration: `create_tahun_ajarans_table`
- [ ] Migration: `create_semesters_table`
- [ ] Migration: `create_mata_kuliahs_table`
- [ ] Migration: `create_mahasiswa_mata_kuliah_table` (pivot)
- [ ] Migration: `create_geofences_table`
- [ ] Migration: `create_jadwals_table`
- [ ] Migration: `create_attendances_table`
- [ ] Migration: `create_attendance_logs_table`
- [ ] Migration: `create_alpha_accumulations_table`
- [ ] Migration: `create_sp_records_table`
- [ ] Migration: `create_leave_requests_table`
- [ ] Migration: `create_prodi_settings_table`
- [ ] Migration: `create_notifications_table`
- [ ] Migration: `create_system_settings_table`
- [ ] Migration: `create_audit_trails_table`
- [ ] Migration: `create_parent_student_table` (relasi orang tua ↔ mahasiswa)
- [ ] Run: `php artisan migrate` — semua berhasil tanpa error

### Task 1.3: Models & Relationships
- [ ] Model: `Role` (hasMany users via pivot)
- [ ] Model: `Prodi` (hasMany users, mataKuliahs, hasOne prodiSetting)
- [ ] Model: `User` (belongsToMany roles, belongsTo prodi, hasMany embeddings, attendances, spRecords, children/parents via parent_student, dll)
- [ ] Model: `FaceEmbedding` (belongsTo user, belongsTo approvedBy)
- [ ] Model: `ReEnrollmentRequest` (belongsTo user, belongsTo approvedBy)
- [ ] Model: `TahunAjaran` (hasMany semesters)
- [ ] Model: `Semester` (belongsTo tahunAjaran, hasMany mataKuliahs)
- [ ] Model: `MataKuliah` (belongsTo semester, prodi, dosen; belongsToMany mahasiswa)
- [ ] Model: `Geofence` (belongsTo prodi, hasMany jadwals)
- [ ] Model: `Jadwal` (belongsTo mataKuliah, geofence)
- [ ] Model: `Attendance` (belongsTo user, jadwal, mataKuliah, approvedBy, overriddenBy)
- [ ] Model: `AttendanceLog` (belongsTo attendance, user)
- [ ] Model: `AlphaAccumulation` (belongsTo user, semester)
- [ ] Model: `SpRecord` (belongsTo user, semester, generatedBy, signedKaprodiBy, signedKajurBy)
- [ ] Model: `LeaveRequest` (belongsTo user, mataKuliah, approvedBy)
- [ ] Model: `ProdiSetting` (belongsTo prodi)
- [ ] Model: `Notification` (belongsTo user)
- [ ] Model: `SystemSetting` (standalone)
- [ ] Model: `AuditTrail` (belongsTo user)
- [ ] Semua model: setup `$fillable`, `$casts`, `$hidden`, soft deletes (yang perlu)

### Task 1.4: Seeders
- [ ] Seeder: `RoleSeeder` (8 roles: super_admin, ketua_jurusan, admin_jurusan, kaprodi, admin_prodi, dosen, mahasiswa, orang_tua)
- [ ] Seeder: `ProdiSeeder` (3 prodi: Teknik Listrik, Teknik Informatika, Teknik Elektro)
- [ ] Seeder: `SystemSettingSeeder` (test_mode, app_name, institution_name, dll)
- [ ] Seeder: `ProdiSettingSeeder` (default settings untuk 3 prodi)
- [ ] Seeder: `UserSeeder` — semua akun development (lihat PRD-03 Section 4.5):
  - 1 Super Admin: administrator@gmail.com
  - 1 Ketua Jurusan: ketua_jurusan@gmail.com
  - 1 Admin Jurusan: admin_jurusan@gmail.com
  - 3 Kaprodi: kaprodi_elektro@gmail.com, kaprodi_informatika@gmail.com, kaprodi_listrik@gmail.com
  - 3 Admin Prodi: admin_prodi_elektro@gmail.com, admin_prodi_informatika@gmail.com, admin_prodi_listrik@gmail.com
  - 9 Dosen: dosen_yusril@gmail.com, dosen_adam@gmail.com, dosen_fitri@gmail.com, dll
  - 15 Mahasiswa: mahasiswa_ahmad@gmail.com, mahasiswa_budi@gmail.com, dll
  - 3 Orang Tua: orangtua_fauzi@gmail.com, orangtua_prasetyo@gmail.com, orangtua_saputra@gmail.com
  - Password semua: `12345678` (bcrypt)
  - must_change_password: true
- [ ] Seeder: `TahunAjaranSeeder` (2025/2026 + semester Genap aktif)
- [ ] Seeder: `MataKuliahSeeder` (contoh: Pemrograman Mobile 5 kelas, lihat PRD-03 Section 4.7)
- [ ] Seeder: `GeofenceSeeder` (7 lokasi contoh, lihat PRD-03 Section 4.8)
- [ ] Seeder: `JadwalSeeder` (5 jadwal contoh, lihat PRD-03 Section 4.9)
- [ ] Seeder: `MahasiswaMataKuliahSeeder` (enrollment MK, lihat PRD-03 Section 4.10)
- [ ] Seeder: `ParentStudentSeeder` (relasi orang tua ↔ mahasiswa)
- [ ] Run: `php artisan db:seed` — semua berhasil

### Task 1.5: API Response & Middleware Setup
- [ ] Buat trait `ApiResponseTrait` (success, error, paginated response format)
- [ ] Buat middleware `CheckRole` (cek role user)
- [ ] Buat middleware `EnsureEnrollmentApproved` (untuk endpoint attendance)
- [ ] Register middleware di `bootstrap/app.php`
- [ ] Setup route groups: `routes/api.php` (versioned: `/api/v1/`)
- [ ] Test: hit endpoint test → response format benar

---

## PHASE 2: AUTHENTICATION & USER MANAGEMENT
**Estimasi: 1.5 minggu**

### Task 2.1: Authentication (Login/Logout)
- [ ] Buat `AuthController`
- [ ] Buat `LoginRequest` (validation: login, password)
- [ ] Implement `login()`: validate credentials, generate Sanctum token, return user + token
- [ ] Implement `logout()`: revoke current token
- [ ] Implement `me()`: return authenticated user with roles & prodi
- [ ] Buat `ForgotPasswordController` (send reset link)
- [ ] Buat `ResetPasswordController` (reset with token)
- [ ] Buat `ChangePasswordController` (old password + new password)
- [ ] Buat `UpdateFcmTokenController` (update FCM token)
- [ ] Routes: POST `/auth/login`, POST `/auth/logout`, GET `/auth/me`, dll
- [ ] Test: login dengan berbagai role → token valid

### Task 2.2: User Management - Super Admin
- [ ] Buat `UserController` (full CRUD)
- [ ] Buat `StoreUserRequest` (validation rules)
- [ ] Buat `UpdateUserRequest` (validation rules)
- [ ] Implement `index()`: list users with filters (role, prodi, status), pagination
- [ ] Implement `store()`: create user + assign role
- [ ] Implement `show()`: detail user + relationships
- [ ] Implement `update()`: update user data
- [ ] Implement `destroy()`: soft delete
- [ ] Implement `assignRole()`: assign/change role
- [ ] Implement `toggleStatus()`: aktif/nonaktif
- [ ] Routes: resource routes + custom routes
- [ ] Middleware: only super_admin

### Task 2.3: User Management - Mahasiswa
- [ ] Buat `MahasiswaController`
- [ ] Buat `StoreMahasiswaRequest` (NIM unique, email unique, prodi required)
- [ ] Buat `UpdateMahasiswaRequest`
- [ ] Implement `index()`: list mahasiswa (filter prodi, kelas, angkatan, status)
- [ ] Implement `store()`: create mahasiswa + auto-assign role + generate default password
- [ ] Implement `show()`: detail + rekap kehadiran summary
- [ ] Implement `update()`: update data mahasiswa
- [ ] Implement `destroy()`: soft delete
- [ ] Implement `import()`: bulk import dari Excel (template)
- [ ] Implement `export()`: export ke Excel
- [ ] Routes + middleware (admin_prodi, admin_jurusan, super_admin)

### Task 2.4: User Management - Dosen
- [ ] Buat `DosenController`
- [ ] Buat `StoreDosenRequest` (NIDN unique, email unique)
- [ ] Buat `UpdateDosenRequest`
- [ ] Implement CRUD (sama pattern seperti mahasiswa)
- [ ] Routes + middleware (admin_prodi, admin_jurusan, super_admin)

### Task 2.5: Profile Management
- [ ] Buat `ProfileController`
- [ ] Implement `show()`: get own profile
- [ ] Implement `update()`: update own profile (nama, email, no_hp, foto)
- [ ] Implement `uploadSignature()`: upload tanda tangan digital (Kaprodi, Kajur)
- [ ] File upload handling (validate type, size, store)
- [ ] Routes (authenticated users)

---

## PHASE 3: ACADEMIC MODULE (CRUD)
**Estimasi: 2 minggu**

### Task 3.1: Tahun Ajaran CRUD
- [ ] Buat `TahunAjaranController`
- [ ] Buat `StoreTahunAjaranRequest` (kode unique, tanggal valid)
- [ ] Buat `UpdateTahunAjaranRequest`
- [ ] Implement CRUD (index, store, show, update, destroy)
- [ ] Implement `activate()`: set aktif (nonaktifkan yang lain)
- [ ] Business logic: hanya 1 yang boleh aktif
- [ ] Routes + middleware (admin_prodi, admin_jurusan, super_admin)
- [ ] Test: CRUD + aktivasi

### Task 3.2: Semester CRUD
- [ ] Buat `SemesterController`
- [ ] Buat `StoreSemesterRequest` (tahun_ajaran_id exists, tanggal valid)
- [ ] Buat `UpdateSemesterRequest`
- [ ] Implement CRUD
- [ ] Implement `activate()`: set aktif + reset alpha accumulation mahasiswa
- [ ] Business logic: saat aktivasi, create alpha_accumulations baru untuk semua mahasiswa aktif
- [ ] Routes + middleware
- [ ] Test: CRUD + aktivasi + reset alpha

### Task 3.3: Mata Kuliah CRUD
- [ ] Buat `MataKuliahController`
- [ ] Buat `StoreMataKuliahRequest` (kode_mk + semester + kelas unique)
- [ ] Buat `UpdateMataKuliahRequest`
- [ ] Implement CRUD
- [ ] Implement `assignMahasiswa()`: assign mahasiswa ke MK (bulk)
- [ ] Implement `removeMahasiswa()`: remove mahasiswa dari MK
- [ ] Implement `getMahasiswa()`: list mahasiswa di MK
- [ ] Routes + middleware
- [ ] Test: CRUD + assign/remove mahasiswa

### Task 3.4: Geofence CRUD
- [ ] Buat `GeofenceController`
- [ ] Buat `StoreGeofenceRequest` (lat/lon valid, radius > 0)
- [ ] Buat `UpdateGeofenceRequest`
- [ ] Implement CRUD
- [ ] Routes + middleware
- [ ] Test: CRUD

### Task 3.5: Jadwal CRUD
- [ ] Buat `JadwalController`
- [ ] Buat `StoreJadwalRequest` (mata_kuliah_id, geofence_id, hari, jam valid)
- [ ] Buat `UpdateJadwalRequest`
- [ ] Implement CRUD
- [ ] Implement validasi bentrok (dosen/ruangan/kelas di waktu sama)
- [ ] Implement `getToday()`: jadwal hari ini (filter by user role)
- [ ] Implement `getByDosen()`: jadwal per dosen
- [ ] Routes + middleware
- [ ] Test: CRUD + validasi bentrok

### Task 3.6: Prodi Settings CRUD
- [ ] Buat `ProdiSettingController`
- [ ] Buat `UpdateProdiSettingRequest` (validate all setting fields)
- [ ] Implement `show()`: get setting per prodi
- [ ] Implement `update()`: update setting per prodi
- [ ] Routes + middleware (admin_prodi, super_admin)
- [ ] Test: get + update settings

---

## PHASE 4: ATTENDANCE SYSTEM (CORE)
**Estimasi: 2 minggu**

### Task 4.1: Enrollment Wajah
- [ ] Buat `EnrollmentController`
- [ ] Buat `SubmitEnrollmentRequest` (embedding array 192, liveness_passed, device, foto file)
- [ ] Implement `submit()`: simpan embedding + upload foto enrollment + status pending
  - Simpan foto enrollment (JPG, max 500KB) ke storage
  - Simpan path foto ke users.foto_enrollment
  - Simpan embedding ke face_embeddings table
- [ ] Implement `status()`: cek status enrollment user
- [ ] Implement `getMyEmbedding()`: get embedding aktif (untuk cache di mobile)
- [ ] Implement `getPending()`: list enrollment pending (admin) — termasuk foto enrollment
- [ ] Implement `approve()`: approve enrollment, update user enrollment_status
- [ ] Implement `reject()`: reject + alasan
- [ ] Buat `ReEnrollmentController`
- [ ] Implement request + approve/reject re-enrollment (foto enrollment diupdate saat re-enroll)
- [ ] Routes + middleware
- [ ] Test: submit → pending → approve → embedding aktif + foto tersimpan

### Task 4.2: Check-in Endpoint
- [ ] Buat `AttendanceController`
- [ ] Buat `CheckinRequest` (validation: jadwal_id, lat, lon, face_distance, dll)
- [ ] Buat `AttendanceService` (business logic layer)
- [ ] Implement service: `validateScheduleActive()` — cek jadwal sedang berlangsung
- [ ] Implement service: `validateGeofence()` — hitung jarak, cek radius
- [ ] Implement service: `validateMockLocation()` — cek flag mock location
- [ ] Implement service: `determinateStatus()` — tentukan status berdasarkan waktu:
  - Dalam toleransi → HADIR
  - Terlambat (dalam batas) → HADIR_TERLAMBAT
  - Terlambat (melebihi batas) → PENDING
- [ ] Implement service: `calculateAlphaMinutes()` — hitung alpha menit
- [ ] Implement controller `checkin()`: orchestrate semua validasi + simpan
- [ ] Buat `AttendanceLogService` — catat setiap attempt ke attendance_logs
- [ ] Routes: POST `/attendance/check-in`
- [ ] Test: semua case (tepat waktu, terlambat, pending, di luar geofence)

### Task 4.3: Check-out Endpoint
- [ ] Buat `CheckoutRequest` (validation: attendance_id, lat, lon, face_distance, dll)
- [ ] Implement service: `validateCheckoutTime()` — tentukan status checkout:
  - Normal (setelah jam selesai - toleransi)
  - Pulang awal (sebelum jam selesai - toleransi)
  - Terlambat checkout (setelah jam selesai + toleransi) → waktu = jam selesai
- [ ] Implement service: `calculateCheckoutAlpha()` — hitung alpha tambahan jika pulang awal
- [ ] Implement service: `calculateEffectiveDuration()` — durasi efektif
- [ ] Implement controller `checkout()`: orchestrate + update attendance record
- [ ] Routes: POST `/attendance/check-out`
- [ ] Test: semua case (normal, pulang awal, terlambat checkout)

### Task 4.4: Auto-Close Scheduler
- [ ] Buat command: `php artisan attendance:auto-close`
- [ ] Logic: cari attendance yang checkin != null, checkout == null, jadwal sudah lewat + toleransi
- [ ] Set checkout_time = jam_selesai, is_auto_closed = true
- [ ] Hitung durasi efektif
- [ ] Register di `app/Console/Kernel.php` (setiap menit)
- [ ] Test: simulasi auto-close

### Task 4.5: Alpha Penuh (Tidak Hadir) Scheduler
- [ ] Buat command: `php artisan attendance:mark-absent`
- [ ] Logic: di akhir hari, cari mahasiswa yang terdaftar di MK tapi tidak punya attendance record
- [ ] Exclude yang punya leave_request approved
- [ ] Create attendance record: status = ALPHA, alpha_menit = durasi MK
- [ ] Register scheduler (setiap hari jam 22:00)
- [ ] Test: simulasi mark absent

### Task 4.6: Alpha Accumulation Service
- [ ] Buat `AlphaAccumulationService`
- [ ] Implement `recalculate(userId, semesterId)`: hitung ulang total alpha dari semua attendance
- [ ] Implement `checkSpStatus(userId, semesterId)`: evaluasi status SP berdasarkan total alpha
- [ ] Implement `getSpThresholds(prodiId)`: ambil threshold dari prodi_settings
- [ ] Trigger recalculate setiap: checkin, checkout, approval, override
- [ ] Update tabel `alpha_accumulations`
- [ ] Test: kalkulasi benar untuk berbagai skenario

### Task 4.7: Offline Sync Endpoint
- [ ] Buat `SyncOfflineRequest` (validation: array of attendance data)
- [ ] Implement `syncOffline()`: terima batch data, validasi timestamp masih dalam range
- [ ] Business logic: reject jika timestamp > 30 menit setelah jadwal selesai
- [ ] Flag: is_offline_synced = true
- [ ] Routes: POST `/attendance/sync-offline`
- [ ] Test: sync valid + sync expired

### Task 4.8: Leave Request (Izin/Sakit)
- [ ] Buat `LeaveRequestController`
- [ ] Buat `StoreLeaveRequest` (jenis, mata_kuliah_id, tanggal, file)
- [ ] Implement `store()`: submit izin + upload file
- [ ] Implement `myLeaves()`: list izin saya (mahasiswa)
- [ ] Implement `pending()`: list izin pending (dosen/admin)
- [ ] Implement `approve()`: approve + update attendance status ke IZIN/SAKIT + recalculate alpha
- [ ] Implement `reject()`: reject + alasan
- [ ] File upload handling (validate: jpg, png, pdf, max 5MB)
- [ ] Routes + middleware
- [ ] Test: submit → approve → alpha berubah

### Task 4.9: Dosen Approval & Override
- [ ] Buat `DosenAttendanceController`
- [ ] Implement `pendingApprovals()`: list pending di kelas yang diampu
- [ ] Implement `approve()`: ubah status pending → hadir_terlambat, recalculate alpha
- [ ] Implement `reject()`: ubah status pending → alpha penuh, recalculate alpha
- [ ] Implement `override()`: manual override kehadiran (wajib alasan)
- [ ] Implement `classToday()`: siapa yang sudah hadir di kelas hari ini (real-time)
- [ ] Implement `classRecap()`: rekap per MK
- [ ] Audit trail untuk setiap override
- [ ] Routes + middleware (dosen only)
- [ ] Test: approve, reject, override

### Task 4.10: Attendance Query & History
- [ ] Implement `today()`: jadwal + status absensi hari ini (mahasiswa)
- [ ] Implement `history()`: riwayat absensi (filter semester, MK, pagination)
- [ ] Implement `summary()`: summary kehadiran semester (total hadir, alpha, izin, persentase)
- [ ] Implement `activeSchedule()`: jadwal yang sedang berlangsung saat ini
- [ ] Routes (mahasiswa)
- [ ] Test: query dengan berbagai filter

---

## PHASE 5: SP & EARLY WARNING SYSTEM
**Estimasi: 1.5 minggu**

### Task 5.1: SP Detection & Notification
- [ ] Buat `SpDetectionService`
- [ ] Implement: setiap kali alpha_accumulation berubah, cek apakah masuk threshold SP baru
- [ ] Implement: cek apakah mendekati threshold (80% dari batas berikutnya)
- [ ] Trigger notification jika status berubah atau mendekati batas
- [ ] Integrate dengan AlphaAccumulationService
- [ ] Test: simulasi mahasiswa naik dari AMAN → SP1 → SP2 → SP3 → DO

### Task 5.2: SP Record Management
- [ ] Buat `SpRecordController`
- [ ] Implement `dashboard()`: overview SP per prodi (count per level)
- [ ] Implement `listMahasiswa()`: list mahasiswa + status SP (sortable, filterable)
- [ ] Implement `detail()`: detail SP mahasiswa (rincian per MK)
- [ ] Implement `mySpRecords()`: SP saya (mahasiswa)
- [ ] Routes + middleware
- [ ] Test: query data SP

### Task 5.3: Generate Dokumen SP (PDF)
- [ ] Buat `SpDocumentService`
- [ ] Buat template Blade untuk PDF SP (header institusi, isi, tanda tangan)
- [ ] Implement `generate()`:
  - Ambil data mahasiswa, total alpha, rincian per MK
  - Generate nomor surat otomatis (format: No/SP[level]/JTE/[bulan]/[tahun])
  - Create sp_record dengan status DRAFT
  - Generate PDF draft
- [ ] Implement `sendToKaprodi()`: ubah status → MENUNGGU_KAPRODI, notif ke kaprodi
- [ ] Routes: POST `/sp/generate`
- [ ] Test: generate PDF, cek format benar

### Task 5.4: SP Approval Flow (Tanda Tangan Digital)
- [ ] Implement `signKaprodi()`: kaprodi approve + tanda tangan
  - Validasi: user adalah kaprodi dari prodi mahasiswa
  - Tempelkan tanda tangan ke PDF
  - Ubah status → MENUNGGU_KAJUR
  - Notif ke Ketua Jurusan
- [ ] Implement `signKajur()`: kajur approve + tanda tangan "Diketahui"
  - Validasi: user adalah ketua jurusan
  - Tempelkan tanda tangan ke PDF
  - Ubah status → FINAL
  - Generate PDF final
  - Notif ke mahasiswa + admin
- [ ] Implement `downloadDocument()`: download PDF SP
- [ ] Routes + middleware (kaprodi, kajur)
- [ ] Test: full flow draft → kaprodi → kajur → final

### Task 5.5: SP History & Tracking
- [ ] Implement list semua SP records (filter: prodi, level, status)
- [ ] Implement detail SP record (termasuk timeline approval)
- [ ] Implement cancel SP (jika ada kesalahan)
- [ ] Routes + middleware
- [ ] Test: query + filter

---

## PHASE 6: NOTIFICATION & EXPORT
**Estimasi: 1 minggu**

### Task 6.1: Notification Service
- [ ] Buat `NotificationService`
- [ ] Implement `send()`: create notification record + push FCM
- [ ] Implement `sendBulk()`: kirim ke multiple users
- [ ] Setup Firebase Admin SDK
- [ ] Implement FCM push (title, body, data payload)
- [ ] Buat notification templates (SP warning, approval, reminder, dll)
- [ ] Test: kirim notifikasi → cek di database + FCM

### Task 6.2: Notification Controller
- [ ] Buat `NotificationController`
- [ ] Implement `index()`: list notifikasi user (pagination, filter type)
- [ ] Implement `unreadCount()`: jumlah belum dibaca
- [ ] Implement `markRead()`: mark 1 as read
- [ ] Implement `markAllRead()`: mark all as read
- [ ] Routes (authenticated)
- [ ] Test: CRUD notifikasi

### Task 6.3: Notification Triggers (SP - Berdasarkan Level)
- [ ] Buat `SpNotificationService` (khusus handle notifikasi SP per level)
- [ ] Trigger: Mendekati SP1 (alpha >= 12.8 jam):
  - Push ke mahasiswa
- [ ] Trigger: Masuk SP1 (alpha >= 16 jam):
  - Push ke mahasiswa
  - In-app ke Admin Prodi
  - In-app ke Kaprodi
  - In-app ke Dosen Pengampu MK terkait (query dosen dari MK yang diambil mahasiswa)
- [ ] Trigger: Mendekati SP2 (alpha >= 25.6 jam):
  - Push ke mahasiswa
  - In-app ke Admin Prodi
- [ ] Trigger: Masuk SP2 (alpha >= 32 jam):
  - Push ke mahasiswa
  - In-app ke Admin Prodi
  - In-app ke Kaprodi
  - In-app ke Ketua Jurusan
- [ ] Trigger: Mendekati SP3 (alpha >= 30.4 jam):
  - Push ke mahasiswa
  - In-app ke Admin Prodi
  - In-app ke Kaprodi
- [ ] Trigger: Masuk SP3 (alpha >= 38 jam):
  - Push ke mahasiswa
  - In-app ke Admin Prodi
  - In-app ke Kaprodi
  - In-app ke Ketua Jurusan
  - In-app ke Admin Jurusan
- [ ] Trigger: Mendekati DO (alpha >= 36.8 jam):
  - Push ke mahasiswa (PERINGATAN KERAS)
  - In-app ke Admin Prodi (URGENT)
  - In-app ke Kaprodi (URGENT)
  - In-app ke Ketua Jurusan (URGENT)
- [ ] Trigger: Masuk DO (alpha >= 46 jam):
  - Push ke mahasiswa (URGENT)
  - In-app ke Admin Prodi (URGENT)
  - In-app ke Kaprodi (URGENT)
  - In-app ke Ketua Jurusan (URGENT)
  - In-app ke Admin Jurusan (URGENT)
- [ ] Implement logic: hanya kirim notifikasi 1x per level (jangan berulang)
  - Simpan flag `notified_approaching_sp1`, `notified_sp1`, dll di alpha_accumulations
  - Cek flag sebelum kirim
- [ ] Implement helper: `getRecipientsBySpLevel(level, mahasiswa)` — return list user yang harus dinotif

### Task 6.3B: Notification Triggers (Non-SP)
- [ ] Trigger: Pending approval baru → in-app ke dosen pengampu
- [ ] Trigger: Approval result (approve/reject) → push ke mahasiswa
- [ ] Trigger: Enrollment result (approve/reject) → push ke mahasiswa
- [ ] Trigger: Leave request result (approve/reject) → push ke mahasiswa
- [ ] Trigger: Reminder absen (15 menit sebelum kelas) → push ke mahasiswa
- [ ] Trigger: SP document needs signature → in-app ke kaprodi/kajur
- [ ] Trigger: SP document final → push ke mahasiswa (bisa download)
- [ ] Register semua triggers di service/event listeners (Laravel Events + Listeners)
- [ ] Test: setiap trigger berjalan dengan penerima yang benar

### Task 6.4: Export Service (Excel)
- [ ] Buat `AttendanceExport` (Maatwebsite Excel)
- [ ] Sheet 1: Summary (nama, NIM, total hadir, total alpha, status SP)
- [ ] Sheet 2: Detail per pertemuan
- [ ] Sheet 3: Rincian alpha per MK
- [ ] Implement filter: semester, prodi, kelas, MK
- [ ] Routes: GET `/reports/export/excel`
- [ ] Test: export → file valid

### Task 6.5: Export Service (PDF)
- [ ] Buat template Blade untuk laporan PDF
- [ ] Header institusi, tabel rekap, footer
- [ ] Implement filter: semester, prodi, kelas, MK
- [ ] Routes: GET `/reports/export/pdf`
- [ ] Test: export → PDF valid

### Task 6.6: Report Endpoints
- [ ] Buat `ReportController`
- [ ] Implement `byMahasiswa()`: rekap per mahasiswa
- [ ] Implement `byMataKuliah()`: rekap per MK (matrix view data)
- [ ] Implement `byKelas()`: rekap per kelas
- [ ] Implement `byProdi()`: rekap per prodi
- [ ] Implement `byJurusan()`: rekap seluruh jurusan
- [ ] Implement dashboard data endpoints (per role: admin, kaprodi, kajur, dosen)
- [ ] Routes + middleware (sesuai role)
- [ ] Test: semua report endpoint return data benar

### Task 6.7: Mode Pengujian (Testing Mode)
- [ ] Buat `TestModeController`
- [ ] Implement `toggle()`: aktifkan/nonaktifkan mode pengujian
- [ ] Implement: saat mode aktif, attendance_logs dicatat dengan is_test_mode = true
- [ ] Implement: endpoint untuk label genuine/impostor pada log
- [ ] Routes + middleware (super_admin only)
- [ ] Test: toggle mode + log tercatat dengan label

### Task 6.8: Analisis & Evaluasi Endpoints
- [ ] Buat `AnalysisController`
- [ ] Implement `geofence()`: data evaluasi geofence (distribusi jarak, success rate)
- [ ] Implement `faceVerification()`: data evaluasi face (distribusi distance, FAR, FRR)
- [ ] Implement `latency()`: data latensi (per device, rata-rata, min, max, P95)
- [ ] Implement `attendanceSp()`: data kehadiran & SP (distribusi, trend)
- [ ] Implement `simultaneousTest()`: data uji simultan (response time per concurrent level)
- [ ] Implement `conventionalComparison()`: data perbandingan (input manual + data sistem)
- [ ] Implement `storeConventionalData()`: input data konvensional (POST)
- [ ] Routes + middleware (super_admin only)
- [ ] Test: semua endpoint return data yang benar
